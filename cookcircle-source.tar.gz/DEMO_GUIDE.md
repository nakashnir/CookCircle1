# CookCircle — Demo Guide

A quick walkthrough of the key user flows for demoing the app.

## Default state

The workspace auto-starts both services. Open the CookCircle preview and you'll see the donation feed logged in as **Yael Ben-David** (user 1). No API keys are required — everything works in local/demo mode.

Switch users at any time using the **"Switch User"** button in the top-right corner.

---

## Flow 1 — Browse the feed and view a donation (as Yael, user 1)

1. Open the feed. You'll see 4–5 available donations across Tel Aviv, Haifa, Jerusalem, Beer Sheva, and Herzliya.
2. Use the filter bar to filter by city or dietary tag (e.g. "Kosher").
3. Click any available donation to open **Donation Details**.
4. Note: the map shows the approximate area only — the exact address is hidden until your request is approved.

**For donation #1 (Maya's Shakshuka in Tel Aviv):** Yael already has an **approved** request, so the exact address and a tighter map are visible on this card.

---

## Flow 2 — Send a pickup request (as David, user 3)

1. Switch to **David Mizrahi** (user 3) using the user switcher.
2. Click on donation #4 or #7 (both available, both belong to other users).
3. Pick a pickup time, add optional notes, and submit the request.
4. Switch back to the **donor** of that donation (user 5 = Eitan, or user 1 = Yael for donation 7) to see the incoming request in **My Donations**.

---

## Flow 3 — Approve a request and reveal the address (as Maya, user 2)

1. Switch to **Maya Cohen** (user 2).
2. Go to **My Donations** → find donation #5 (available — "Shakshuka Leftovers").
3. If a pending request exists, click **Approve**. The requester now gets the exact address.
4. Switch to the requester's account and view the donation — the exact address and map are now revealed.

---

## Flow 4 — Mark pickup complete and leave a review (as Yael, user 1)

1. Switch to **Yael** (user 1).
2. Go to **My Requests** → find the approved request on donation #1.
3. Click **Mark as Picked Up** — the donation moves to `picked_up` status.
4. A **Leave a Review** prompt appears. Rate the donor and submit.
5. Maya's profile rating updates immediately.

---

## Flow 5 — Create a donation with location confirmation (as any user)

1. Click **+ Donate Food** on the home feed.
2. Fill in the food details (title, type, quantity, expiry).
3. Enter a structured address: city → street → house number → pickup notes.
4. Click **Check Location** — the 2-step flow geocodes the address.
   - In local/demo mode: shows "Location not verified — fallback mode" with an area map.
   - With a real Google key: shows a verified result with precision level.
5. Click **Publish anyway** (fallback) or **Confirm & Publish** (verified) to create the listing.

---

## Flow 6 — Edit a donation (address guard demo)

1. Go to **My Donations** and click **Edit details** on any reservation.
2. Try changing the address fields — a warning banner appears if the donation is reserved.
3. Backend will block the change if an approved request is active (returns 409).

---

## Privacy model summary (for demos)

| Viewer | What they see |
|---|---|
| **Donor** | Full address, exact map, geocode quality |
| **Approved/completed requester** | Full address, exact map |
| **Pending requester** | City only, approximate area map |
| **Public / other users** | City only, approximate area map |

The approximate area is offset ~500 m from the exact location in Google mode (or uses pseudo-coords in fallback mode). The area map is always shown; the exact map only appears after approval — and only when real Google coordinates are available.

---

## Health check

```bash
curl localhost:80/api/health
# → { "status": "ok", "db": "ok", "media": "local", "location": "local" }
```

`location: "local"` means demo/fallback mode (no `GOOGLE_MAPS_API_KEY` set). All features work. See `.env.example` for optional integration keys.

---

## Reset demo data

```bash
psql "$DATABASE_URL" -c "truncate users, donations, pickup_requests, reviews restart identity cascade;"
# Then restart the API Server workflow — seed runs automatically on boot.
```
