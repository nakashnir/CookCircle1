import type { Request, Response } from "express";

// Lightweight demo identity layer.
// Stores the selected user id in a plain HTTP-only cookie. There is NO
// password, signup, or real auth — this is intentional. The whole purpose
// is letting the demo switch between seeded users so the rest of the app
// (privacy gating, "my donations", "my requests", reviews) can work as if
// it had real users.

export const SESSION_COOKIE = "ccUserId";
export const DEFAULT_USER_ID = 1;

export function getSessionUserId(req: Request): number {
  const raw = (req as Request & { cookies?: Record<string, string> }).cookies?.[
    SESSION_COOKIE
  ];
  const n = Number(raw);
  return Number.isFinite(n) && n > 0 ? n : DEFAULT_USER_ID;
}

export function setSessionUserId(res: Response, userId: number) {
  res.cookie(SESSION_COOKIE, String(userId), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 1000 * 60 * 60 * 24 * 30,
  });
}
