import { Router, type IRouter, type Request, type Response } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import { getSessionUserId, setSessionUserId } from "../lib/session";
import { ensureSeed } from "./cookcircle-seed";

const router: IRouter = Router();

let seeded = false;
router.use(async (_req, _res, next) => {
  if (!seeded) {
    try {
      await ensureSeed();
      seeded = true;
    } catch (err) {
      console.error("session: seed failed", err);
    }
  }
  next();
});

function shapeUser(u: typeof usersTable.$inferSelect) {
  return {
    id: u.id,
    displayName: u.displayName,
    email: u.email,
    phone: u.phone,
    dietaryPreferences: u.dietaryPreferences ?? [],
    discreetPickup: u.discreetPickup,
    rating: u.rating,
    reviewCount: u.reviewCount,
  };
}

router.get("/session/me", async (req: Request, res: Response) => {
  const userId = getSessionUserId(req);
  const [u] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!u) {
    res.status(404).json({ error: "Session user not found" });
    return;
  }
  res.json(shapeUser(u));
});

router.post("/session/select-user", async (req: Request, res: Response) => {
  const userId = Number(req.body?.userId);
  if (!Number.isFinite(userId) || userId <= 0) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }
  const [u] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!u) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  setSessionUserId(res, u.id);
  res.json(shapeUser(u));
});

export default router;
