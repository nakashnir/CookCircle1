export type DietaryTag = 'kosher' | 'gluten_free' | 'vegan' | 'vegetarian';
export type DonationStatus = 'available' | 'reserved' | 'picked_up' | 'cancelled' | 'expired';
export type RequestStatus = 'pending' | 'approved' | 'cancelled' | 'completed';

export interface User {
  id: number;
  displayName: string;
  email: string;
  phone: string;
  dietaryPreferences: DietaryTag[];
  discreetPickup: boolean;
  rating: number;
  reviewCount: number;
}

export interface Donation {
  id: number;
  title: string;
  description: string;
  foodType: string;
  quantity: string;
  expiryDate: string;
  dietaryTags: DietaryTag[];
  city: string;
  address: string | null;
  donorId: number;
  status: DonationStatus;
  createdAt: string;
  hideAddress?: boolean;
  allowDiscreet?: boolean;
  imageUrl?: string | null;
  imagePublicId?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  canSeeAddress?: boolean;
}

export interface PickupRequest {
  id: number;
  donationId: number;
  requesterId: number;
  pickupTime: string;
  notes: string;
  discreetPickup: boolean;
  status: RequestStatus;
  createdAt: string;
}

export interface Review {
  id: number;
  donationId: number;
  requestId: number;
  reviewerId: number;
  revieweeId: number;
  rating: number;
  comment: string;
  createdAt: string;
}

const API_BASE = '/api';

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    ...init,
  });
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body?.error) message = body.error;
    } catch {
      /* ignore */
    }
    throw new Error(message);
  }
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

export type DonationDraft = Omit<
  Donation,
  'id' | 'donorId' | 'status' | 'createdAt'
>;

export interface DonationListOptions {
  city?: string;
  dietary?: DietaryTag[];
  status?: DonationStatus | 'any';
  sort?: 'newest' | 'expiring' | 'nearest';
  lat?: number;
  lng?: number;
  radiusKm?: number;
}

export interface DonationWithDistance extends Donation {
  distanceKm?: number | null;
}

function buildDonationQuery(opts?: DonationListOptions): string {
  if (!opts) return '';
  const p = new URLSearchParams();
  if (opts.city) p.set('city', opts.city);
  if (opts.dietary && opts.dietary.length) p.set('dietary', opts.dietary.join(','));
  if (opts.status) p.set('status', opts.status);
  if (opts.sort) p.set('sort', opts.sort);
  if (opts.lat != null) p.set('lat', String(opts.lat));
  if (opts.lng != null) p.set('lng', String(opts.lng));
  if (opts.radiusKm != null) p.set('radiusKm', String(opts.radiusKm));
  const s = p.toString();
  return s ? `?${s}` : '';
}

export const api = {
  listDonations: (opts?: DonationListOptions) =>
    request<DonationWithDistance[]>(`/donations${buildDonationQuery(opts)}`),
  listRequests: () => request<PickupRequest[]>('/requests'),
  listReviews: () => request<Review[]>('/reviews'),

  getCurrentUser: () => request<User>('/session/me'),

  selectUser: (userId: number) =>
    request<User>('/session/select-user', {
      method: 'POST',
      body: JSON.stringify({ userId }),
    }),

  listUsers: () => request<User[]>('/users'),

  createDonation: (draft: DonationDraft & { image?: { data: string } }) =>
    request<Donation>('/donations', {
      method: 'POST',
      body: JSON.stringify(draft),
    }),

  updateDonation: (donationId: number, patch: Partial<Donation>) =>
    request<Donation>(`/donations/${donationId}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }),

  deleteDonation: (donationId: number) =>
    request<void>(`/donations/${donationId}`, { method: 'DELETE' }),

  createPickupRequest: (
    donationId: number,
    pickupTime: string,
    notes: string,
    discreetPickup: boolean,
  ) =>
    request<PickupRequest>(`/donations/${donationId}/requests`, {
      method: 'POST',
      body: JSON.stringify({ pickupTime, notes, discreetPickup }),
    }),

  setRequestStatus: (requestId: number, status: RequestStatus) => {
    if (status === 'completed') {
      return request<PickupRequest>(`/requests/${requestId}/complete`, {
        method: 'POST',
      });
    }
    if (status === 'cancelled') {
      return request<PickupRequest>(`/requests/${requestId}/cancel`, {
        method: 'POST',
      });
    }
    return request<PickupRequest>(`/requests/${requestId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  },

  submitReview: (requestId: number, rating: number, comment: string) =>
    request<Review>(`/requests/${requestId}/reviews`, {
      method: 'POST',
      body: JSON.stringify({ rating, comment }),
    }),
};
