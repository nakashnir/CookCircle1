import { useCallback, useEffect, useState } from 'react';
import {
  api,
  type DietaryTag,
  type Donation,
  type DonationListOptions,
  type DonationStatus,
  type DonationWithDistance,
  type PickupRequest,
  type RequestStatus,
  type Review,
  type User,
} from './lib/api';

const FOOD_EMOJI_MAP: Array<{ match: RegExp; emoji: string }> = [
  { match: /produce|veg|fruit|salad/i, emoji: '🥬' },
  { match: /bake|bread|pastry|cake/i, emoji: '🥐' },
  { match: /prepared|meal|cooked|soup/i, emoji: '🍲' },
  { match: /non.?perishable|canned|pantry/i, emoji: '🥫' },
  { match: /dairy|cheese|milk|yogurt/i, emoji: '🧀' },
  { match: /meat|seafood|fish|poultry/i, emoji: '🍱' },
];

function pickFoodEmoji(foodType?: string | null): string {
  if (!foodType) return '🥗';
  for (const { match, emoji } of FOOD_EMOJI_MAP) if (match.test(foodType)) return emoji;
  return '🥗';
}

function isPlaceholderUrl(url?: string | null): boolean {
  if (!url) return true;
  return /picsum\.photos/i.test(url);
}

function DonationImage({ url, foodType, seedId, large = false }: {
  url?: string | null;
  foodType?: string | null;
  seedId?: number;
  large?: boolean;
}) {
  if (url && !isPlaceholderUrl(url)) {
    return <img src={url} alt="" className="absolute inset-0 w-full h-full object-cover" />;
  }
  const gradIdx = ((seedId ?? 0) + (foodType ? foodType.length : 0)) % 6;
  const emoji = pickFoodEmoji(foodType);
  return (
    <div className={`absolute inset-0 flex items-center justify-center food-grad-${gradIdx}`}>
      <span className={large ? 'food-emoji-lg' : 'food-emoji'}>{emoji}</span>
    </div>
  );
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'feed' | 'details' | 'create' | 'edit' | 'my-donations' | 'requests' | 'review' | 'profile'>('feed');
  const [selectedDonationId, setSelectedDonationId] = useState<number | null>(null);
  const [selectedRequestId, setSelectedRequestId] = useState<number | null>(null);
  const [editDonationId, setEditDonationId] = useState<number | null>(null);
  const [donations, setDonations] = useState<DonationWithDistance[]>([]);
  // Unfiltered donation index (status=any) used by Details/Edit/MyDonations/
  // MyRequests/Review screens so the feed's status filter cannot hide
  // donations that are still referenced by other lifecycle flows.
  const [allDonations, setAllDonations] = useState<DonationWithDistance[]>([]);
  const [requests, setRequests] = useState<PickupRequest[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [toast, setToast] = useState<{ kind: 'success' | 'error'; message: string } | null>(null);
  const [busy, setBusy] = useState(false);

  // Feed filter / sort / proximity state — owned at App level so it survives
  // navigation and can be re-applied after mutations.
  const [filterCity, setFilterCity] = useState<string>('');
  const [filterDietary, setFilterDietary] = useState<DietaryTag | ''>('');
  const [filterStatus, setFilterStatus] = useState<DonationStatus | 'any'>('available');
  const [sortMode, setSortMode] = useState<'newest' | 'expiring' | 'nearest'>('newest');
  const [origin, setOrigin] = useState<{ lat: number; lng: number } | null>(null);
  const [originError, setOriginError] = useState<string | null>(null);

  const showToast = (kind: 'success' | 'error', message: string) => {
    setToast({ kind, message });
    window.setTimeout(() => setToast(null), 3000);
  };

  const buildDonationOpts = useCallback((): DonationListOptions => {
    const opts: DonationListOptions = {
      status: filterStatus,
      sort: sortMode,
    };
    if (filterCity) opts.city = filterCity;
    if (filterDietary) opts.dietary = [filterDietary];
    if (origin) {
      opts.lat = origin.lat;
      opts.lng = origin.lng;
    }
    return opts;
  }, [filterCity, filterDietary, filterStatus, sortMode, origin]);

  const loadDonations = useCallback(async () => {
    try {
      const d = await api.listDonations(buildDonationOpts());
      setDonations(d);
      setLoadError(null);
    } catch (err: any) {
      setLoadError(err?.message ?? 'Failed to load donations');
    }
  }, [buildDonationOpts]);

  const refreshAll = async () => {
    try {
      const [d, mine, r, rv, me, allUsers] = await Promise.all([
        api.listDonations(buildDonationOpts()),
        api.listDonations({ status: 'any' }),
        api.listRequests(),
        api.listReviews(),
        api.getCurrentUser(),
        api.listUsers(),
      ]);
      setDonations(d);
      setAllDonations(mine);
      setRequests(r);
      setReviews(rv);
      setCurrentUser(me);
      setUsers(allUsers);
      setLoadError(null);
    } catch (err: any) {
      setLoadError(err?.message ?? 'Failed to load data');
    }
  };

  useEffect(() => { refreshAll(); /* eslint-disable-next-line */ }, []);
  useEffect(() => { loadDonations(); }, [loadDonations]);

  const useMyLocation = () => {
    setOriginError(null);
    if (!navigator.geolocation) {
      setOriginError('Geolocation not supported in this browser');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => setOrigin({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      (err) => setOriginError(err.message || 'Could not get location'),
      { timeout: 8000 },
    );
  };

  const clearOrigin = () => { setOrigin(null); if (sortMode === 'nearest') setSortMode('newest'); };

  const switchUser = async (userId: number) => {
    try {
      const me = await api.selectUser(userId);
      setCurrentUser(me);
      await refreshAll();
      showToast('success', `Switched to ${me.displayName}`);
    } catch (err: any) {
      showToast('error', err?.message ?? 'Switch failed');
    }
  };

  const viewDonationDetails = (donationId: number) => {
    setSelectedDonationId(donationId);
    setCurrentScreen('details');
  };

  const runMutation = async (label: string, op: () => Promise<unknown>, successMsg?: string) => {
    setBusy(true);
    try {
      await op();
      await refreshAll();
      if (successMsg) showToast('success', successMsg);
      return true;
    } catch (err: any) {
      showToast('error', `${label}: ${err?.message ?? 'failed'}`);
      return false;
    } finally {
      setBusy(false);
    }
  };

  const createPickupRequest = async (donationId: number, pickupTime: string, notes: string, discreetPickup: boolean) => {
    const ok = await runMutation('Send request', () =>
      api.createPickupRequest(donationId, pickupTime, notes, discreetPickup),
      'Pickup request sent',
    );
    if (ok) setCurrentScreen('requests');
  };

  const createDonation = async (donation: Omit<Donation, 'id' | 'donorId' | 'status' | 'createdAt'> & { image?: { data: string } }) => {
    const ok = await runMutation('Create donation', () =>
      api.createDonation(donation),
      'Donation published',
    );
    if (ok) setCurrentScreen('my-donations');
  };

  const updateDonation = async (donationId: number, patch: Partial<Donation>) => {
    const ok = await runMutation('Update donation', () =>
      api.updateDonation(donationId, patch),
      'Donation updated',
    );
    if (ok) setCurrentScreen('my-donations');
  };

  const updateRequestStatus = async (requestId: number, newStatus: RequestStatus) => {
    const labels: Record<RequestStatus, string> = {
      pending: 'Set to pending',
      approved: 'Approve request',
      cancelled: 'Cancel request',
      completed: 'Complete pickup',
    };
    await runMutation(
      labels[newStatus],
      () => api.setRequestStatus(requestId, newStatus),
      newStatus === 'approved' ? 'Request approved' : newStatus === 'cancelled' ? 'Request cancelled' : newStatus === 'completed' ? 'Pickup marked complete' : undefined,
    );
  };

  const openReviewScreen = (requestId: number) => {
    setSelectedRequestId(requestId);
    setCurrentScreen('review');
  };

  const openEditScreen = (donationId: number) => {
    setEditDonationId(donationId);
    setCurrentScreen('edit');
  };

  const submitReview = async (requestId: number, rating: number, comment: string) => {
    const ok = await runMutation('Submit review', () =>
      api.submitReview(requestId, rating, comment),
      'Review submitted',
    );
    if (ok) setCurrentScreen('requests');
  };

  const deleteDonation = async (donationId: number) => {
    await runMutation('Delete donation', () =>
      api.deleteDonation(donationId),
      'Donation deleted',
    );
  };

  const setDonationStatus = async (donationId: number, next: DonationStatus) => {
    const labels: Partial<Record<DonationStatus, string>> = {
      cancelled: 'Donation cancelled',
      expired: 'Donation marked expired',
      available: 'Donation reopened',
    };
    await runMutation('Update status', () =>
      api.updateDonation(donationId, { status: next }),
      labels[next],
    );
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen app-background flex items-center justify-center text-zinc-500">
        {loadError ? `⚠️ ${loadError}` : 'Loading…'}
      </div>
    );
  }

  return (
    <div className="min-h-screen app-background">
      <Header
        currentScreen={currentScreen}
        onNavigate={setCurrentScreen}
        currentUser={currentUser}
        users={users}
        onSwitchUser={switchUser}
      />
      <main className="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-8">
        {loadError && (
          <div className="alert-pending mb-6">⚠️ {loadError}</div>
        )}
        {toast && (
          <div className={`mb-6 rounded-lg px-4 py-3 text-sm font-medium ${toast.kind === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 'bg-red-100 text-red-800 border border-red-200'}`}>
            {toast.kind === 'success' ? '✓ ' : '⚠️ '}{toast.message}
          </div>
        )}
        {busy && (
          <div className="mb-4 text-xs text-zinc-500">Working…</div>
        )}
        {currentScreen === 'feed' && (
          <DonationFeed
            donations={donations}
            users={users}
            onViewDetails={viewDonationDetails}
            filterCity={filterCity} setFilterCity={setFilterCity}
            filterDietary={filterDietary} setFilterDietary={setFilterDietary}
            filterStatus={filterStatus} setFilterStatus={setFilterStatus}
            sortMode={sortMode} setSortMode={setSortMode}
            origin={origin}
            useMyLocation={useMyLocation}
            clearOrigin={clearOrigin}
            originError={originError}
          />
        )}
        {currentScreen === 'details' && selectedDonationId && (() => {
          const d = allDonations.find(x => x.id === selectedDonationId);
          const donor = d ? users.find(u => u.id === d.donorId) : undefined;
          if (!d || !donor) return <EmptyState message="Donation not found" />;
          return (
            <DonationDetails
              donation={d}
              donor={donor}
              onBack={() => setCurrentScreen('feed')}
              onSubmitRequest={createPickupRequest}
              currentUserId={currentUser.id}
              requests={requests}
            />
          );
        })()}
        {currentScreen === 'create' && <CreateDonation onBack={() => setCurrentScreen('feed')} onSubmit={createDonation} />}
        {currentScreen === 'edit' && editDonationId && (() => {
          const d = allDonations.find(x => x.id === editDonationId);
          if (!d) return <EmptyState message="Donation not found" />;
          return (
            <EditDonation
              donation={d}
              onBack={() => setCurrentScreen('my-donations')}
              onSubmit={(patch) => updateDonation(editDonationId, patch)}
            />
          );
        })()}
        {currentScreen === 'my-donations' && (
          <MyDonations
            donations={allDonations.filter(d => d.donorId === currentUser.id)}
            requests={requests}
            users={users}
            onViewDetails={viewDonationDetails}
            onDelete={deleteDonation}
            onEdit={openEditScreen}
            onApprove={(rid: number) => updateRequestStatus(rid, 'approved')}
            onDecline={(rid: number) => updateRequestStatus(rid, 'cancelled')}
            onSetStatus={setDonationStatus}
          />
        )}
        {currentScreen === 'requests' && (
          <MyRequests
            requests={requests.filter(r => r.requesterId === currentUser.id)}
            donations={allDonations}
            users={users}
            onViewDonation={viewDonationDetails}
            onUpdateStatus={updateRequestStatus}
            onLeaveReview={openReviewScreen}
            reviews={reviews}
          />
        )}
        {currentScreen === 'review' && selectedRequestId && (() => {
          const req = requests.find(r => r.id === selectedRequestId);
          const d = req ? allDonations.find(x => x.id === req.donationId) : undefined;
          const donor = d ? users.find(u => u.id === d.donorId) : undefined;
          if (!req || !d || !donor) return <EmptyState message="Pickup not found" />;
          return (
            <ReviewRating
              request={req}
              donation={d}
              donor={donor}
              onBack={() => setCurrentScreen('requests')}
              onSubmit={(rating: number, comment: string) => submitReview(selectedRequestId!, rating, comment)}
            />
          );
        })()}
        {currentScreen === 'profile' && <Profile user={currentUser} onBack={() => setCurrentScreen('feed')} />}
      </main>
    </div>
  );
}

function Header({ currentScreen, onNavigate, currentUser, users, onSwitchUser }: {
  currentScreen: string;
  onNavigate: (screen: any) => void;
  currentUser: User;
  users: User[];
  onSwitchUser: (id: number) => void;
}) {
  return (
    <header className="header-gradient sticky top-0 z-30">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between px-4 md:px-8 py-3 md:py-4 gap-3">
        <button onClick={() => onNavigate('feed')} className="flex items-center gap-3">
          <span className="brand-logo">🌿</span>
          <span className="brand-wordmark">CookCircle</span>
        </button>
        <nav className="flex gap-1 order-3 md:order-2 w-full md:w-auto overflow-x-auto">
          {[['feed', 'Home'], ['my-donations', 'My Donations'], ['requests', 'My Requests'], ['profile', 'Profile']].map(([screen, label]) => (
            <button
              key={screen}
              onClick={() => onNavigate(screen)}
              className={`nav-link ${currentScreen === screen ? 'nav-active' : ''}`}
            >
              {label}
            </button>
          ))}
        </nav>
        <div className="flex items-center gap-2 md:gap-3 order-2 md:order-3 ml-auto md:ml-0">
          <select
            value={currentUser.id}
            onChange={(e) => onSwitchUser(Number(e.target.value))}
            className="user-switcher"
            title="Switch demo user"
          >
            {users.map(u => (
              <option key={u.id} value={u.id}>👤 {u.displayName}</option>
            ))}
          </select>
          <button onClick={() => onNavigate('create')} className="cta-button" aria-label="Create donation">
            <span aria-hidden>＋</span><span className="hidden sm:inline">Create Donation</span>
          </button>
        </div>
      </div>
    </header>
  );
}

function StatusBadge({ status }: { status: DonationStatus | RequestStatus }) {
  const getClass = () => {
    switch (status) {
      case 'available': return 'status-available';
      case 'reserved': return 'status-reserved';
      case 'picked_up':
      case 'completed': return 'status-completed';
      case 'approved': return 'status-approved';
      case 'pending': return 'status-pending';
      case 'cancelled': return 'status-cancelled';
      case 'expired': return 'status-expired';
      default: return 'status-cancelled';
    }
  };
  const label = status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  return (
    <span className={`status-badge ${getClass()}`}>
      <span className="status-dot"></span>
      {label}
    </span>
  );
}

function DietaryTagBadge({ tag }: { tag: DietaryTag }) {
  const labels: Record<DietaryTag, string> = {
    kosher: 'Kosher', gluten_free: 'Gluten-Free', vegan: 'Vegan', vegetarian: 'Vegetarian',
  };
  return <span className="dietary-tag">{labels[tag]}</span>;
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="empty-state">
      <div className="max-w-md mx-auto">
        <div className="empty-icon">📦</div>
        <p className="empty-text">{message}</p>
      </div>
    </div>
  );
}

function expiryHint(iso: string): { label: string; soon: boolean } | null {
  if (!iso) return null;
  const ms = new Date(iso).getTime() - Date.now();
  if (Number.isNaN(ms)) return null;
  if (ms < 0) return { label: 'Expired', soon: true };
  const hours = Math.round(ms / (1000 * 60 * 60));
  if (hours < 24) return { label: `${hours}h left`, soon: hours <= 6 };
  const days = Math.round(hours / 24);
  return { label: `${days}d left`, soon: false };
}

function DonationCard({ donation, donor, onViewDetails }: { donation: DonationWithDistance; donor: User; onViewDetails: (id: number) => void; }) {
  const expiry = expiryHint(donation.expiryDate);
  return (
    <div className="card flex flex-col">
      <div className="card-image">
        <DonationImage url={donation.imageUrl} foodType={donation.foodType} seedId={donation.id} />
        <div className="image-badge">
          <StatusBadge status={donation.status} />
        </div>
        {donation.distanceKm != null && (
          <div className="image-badge-right">
            <span className="distance-pill">📍 {donation.distanceKm.toFixed(1)} km</span>
          </div>
        )}
      </div>
      <div className="card-body flex-1 flex flex-col">
        <h3 className="card-title">{donation.title}</h3>
        <div className="card-meta">
          <span>{donor.displayName}</span>
          <span className="text-zinc-300">·</span>
          <span className="card-rating">⭐ {donor.rating.toFixed(1)}</span>
        </div>
        <div className="mt-4 space-y-2 text-[13.5px]">
          <div className="card-info"><span className="card-label">{donation.foodType}</span><span className="card-value">{donation.quantity}</span></div>
          <div className="card-location"><span>📍</span><span>{donation.city}</span></div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5 mt-3">
          {expiry && donation.status === 'available' && (
            <span className={`expiry-pill ${expiry.soon ? 'is-soon' : ''}`}>⏱ {expiry.label}</span>
          )}
          {donation.dietaryTags.map((tag) => <DietaryTagBadge key={tag} tag={tag} />)}
        </div>
        <button onClick={() => onViewDetails(donation.id)} className="btn-primary w-full mt-5">
          View details <span aria-hidden>→</span>
        </button>
      </div>
    </div>
  );
}

function DonationFeed({
  donations, users, onViewDetails,
  filterCity, setFilterCity,
  filterDietary, setFilterDietary,
  filterStatus, setFilterStatus,
  sortMode, setSortMode,
  origin, useMyLocation, clearOrigin, originError,
}: {
  donations: DonationWithDistance[];
  users: User[];
  onViewDetails: (id: number) => void;
  filterCity: string; setFilterCity: (v: string) => void;
  filterDietary: DietaryTag | ''; setFilterDietary: (v: DietaryTag | '') => void;
  filterStatus: DonationStatus | 'any'; setFilterStatus: (v: DonationStatus | 'any') => void;
  sortMode: 'newest' | 'expiring' | 'nearest'; setSortMode: (v: 'newest' | 'expiring' | 'nearest') => void;
  origin: { lat: number; lng: number } | null;
  useMyLocation: () => void;
  clearOrigin: () => void;
  originError: string | null;
}) {
  const [searchQuery, setSearchQuery] = useState('');

  const visible = donations.filter((d) =>
    !searchQuery || d.title.toLowerCase().includes(searchQuery.toLowerCase()),
  );

  const cities = Array.from(new Set(donations.map(d => d.city)));

  return (
    <div>
      <div className="mb-8">
        <div className="eyebrow mb-2">Community feed</div>
        <h1 className="page-title">Fresh food, shared nearby.</h1>
        <p className="page-subtitle">Discover surplus meals and ingredients your neighbors are sharing today.</p>
      </div>
      <div className="filter-card mb-8">
        <div className="input-affix mb-3">
          <span className="input-affix-icon">🔍</span>
          <input
            type="text"
            placeholder="Search donations by name, ingredient, or dish…"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <select value={filterCity} onChange={(e) => setFilterCity(e.target.value)} className="input-field">
            <option value="">📍 All cities</option>
            {cities.map(city => <option key={city} value={city}>{city}</option>)}
          </select>
          <select value={filterDietary} onChange={(e) => setFilterDietary(e.target.value as DietaryTag | '')} className="input-field">
            <option value="">🥗 All dietary tags</option>
            <option value="vegan">Vegan</option>
            <option value="vegetarian">Vegetarian</option>
            <option value="gluten_free">Gluten-Free</option>
            <option value="kosher">Kosher</option>
          </select>
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value as DonationStatus | 'any')} className="input-field">
            <option value="available">● Available only</option>
            <option value="reserved">Reserved</option>
            <option value="picked_up">Picked up</option>
            <option value="expired">Expired</option>
            <option value="cancelled">Cancelled</option>
            <option value="any">Any status</option>
          </select>
          <select value={sortMode} onChange={(e) => setSortMode(e.target.value as any)} className="input-field">
            <option value="newest">↓ Newest first</option>
            <option value="expiring">⏱ Expiring soonest</option>
            <option value="nearest" disabled={!origin}>📍 Nearest{origin ? '' : ' (set location)'}</option>
          </select>
        </div>
        <div className="mt-3 flex items-center gap-3 text-sm flex-wrap">
          {origin ? (
            <>
              <span className="distance-pill">📍 {origin.lat.toFixed(3)}, {origin.lng.toFixed(3)}</span>
              <button onClick={clearOrigin} className="btn-ghost">Clear location</button>
            </>
          ) : (
            <button onClick={useMyLocation} className="btn-ghost">📍 Use my location</button>
          )}
          {originError && <span className="text-red-600 text-xs">{originError}</span>}
        </div>
      </div>
      {visible.length === 0 ? (
        <EmptyState message="No donations match your filters yet. Try widening your search." />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {visible.map((d) => {
            const donor = users.find(u => u.id === d.donorId);
            if (!donor) return null;
            return <DonationCard key={d.id} donation={d} donor={donor} onViewDetails={onViewDetails} />;
          })}
        </div>
      )}
    </div>
  );
}

function DonationDetails({ donation, donor, onBack, onSubmitRequest, currentUserId, requests }: {
  donation: Donation; donor: User; onBack: () => void; onSubmitRequest: any; currentUserId: number; requests: PickupRequest[];
}) {
  const [pickupTime, setPickupTime] = useState('');
  const [notes, setNotes] = useState('');
  const [discreetPickup, setDiscreetPickup] = useState(false);

  const handleSubmit = () => {
    if (!pickupTime) { alert('Please select a pickup time'); return; }
    onSubmitRequest(donation.id, pickupTime, notes, discreetPickup);
  };

  const formatDateTime = (iso: string) => new Date(iso).toLocaleString('en-US', { month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true });
  const isOwnDonation = donation.donorId === currentUserId;
  void requests;
  const canSeeAddress = donation.canSeeAddress ?? !donation.hideAddress;

  return (
    <div>
      <div className="breadcrumb">
        <button onClick={onBack} className="breadcrumb-link">Home</button>
        <span>/</span>
        <span className="breadcrumb-current">Donation Details</span>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
        <div>
          <div className="card-image-large mb-6">
            <DonationImage url={donation.imageUrl} foodType={donation.foodType} seedId={donation.id} large />
            <div className="image-badge">
              <StatusBadge status={donation.status} />
            </div>
          </div>
          <div className="card p-6">
            <div className="mb-4">
              <div className="eyebrow mb-1">{donation.foodType}</div>
              <h1 className="details-title">{donation.title}</h1>
            </div>
            <div className="space-y-4 mb-6">
              <div><div className="detail-label">Description</div><div className="detail-value">{donation.description}</div></div>
              <div className="grid grid-cols-2 gap-4">
                <div><div className="detail-label">Food Type</div><div className="detail-value">{donation.foodType}</div></div>
                <div><div className="detail-label">Quantity</div><div className="detail-value">{donation.quantity}</div></div>
              </div>
              <div><div className="detail-label">Expiry Date</div><div className="detail-value">{formatDateTime(donation.expiryDate)}</div></div>
              {donation.dietaryTags.length > 0 && (
                <div><div className="detail-label">Dietary Tags</div><div className="flex gap-2 flex-wrap">{donation.dietaryTags.map(tag => <DietaryTagBadge key={tag} tag={tag} />)}</div></div>
              )}
              <div>
                <div className="detail-label">Pickup Location</div>
                <div className="flex items-start gap-2">
                  <span className="text-lg">📍</span>
                  <div>
                    <div className="detail-value">{canSeeAddress ? `${donation.address}, ${donation.city}` : donation.city}</div>
                    {!canSeeAddress && <div className="detail-privacy">Full address shared after request approval</div>}
                  </div>
                </div>
                {canSeeAddress && donation.latitude != null && donation.longitude != null && (
                  <div className="mt-3">
                    <div className="map-frame">
                      <iframe
                        title="Pickup map"
                        className="w-full h-52 block"
                        loading="lazy"
                        src={`https://www.openstreetmap.org/export/embed.html?bbox=${donation.longitude - 0.005}%2C${donation.latitude - 0.003}%2C${donation.longitude + 0.005}%2C${donation.latitude + 0.003}&layer=mapnik&marker=${donation.latitude}%2C${donation.longitude}`}
                      />
                    </div>
                    <div className="mt-1 text-xs text-zinc-500">
                      Coords: {donation.latitude.toFixed(5)}, {donation.longitude.toFixed(5)}
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="donor-section">
              <div className="detail-label mb-3">Donor</div>
              <div className="flex items-center gap-4">
                <div className="donor-avatar">👤</div>
                <div className="flex-1">
                  <div className="donor-name">{donor.displayName}</div>
                  <div className="flex items-center gap-1 text-sm">
                    {[...Array(5)].map((_, i) => <span key={i} className={i < Math.floor(donor.rating) ? 'star-filled' : 'star-empty'}>⭐</span>)}
                    <span className="rating-value ml-1">{donor.rating.toFixed(1)}</span>
                    <span className="rating-count">({donor.reviewCount} reviews)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
          {isOwnDonation ? (
            <div className="card p-8 text-center"><span className="empty-text">This is your donation. You cannot request pickup for your own listing.</span></div>
          ) : donation.status !== 'available' ? (
            <div className="card p-8 text-center"><span className="empty-text">This donation is not available for pickup requests.</span></div>
          ) : (
            <div className="card p-6">
              <div className="eyebrow mb-1">Pickup request</div>
              <h2 className="section-title mb-5">Reserve this donation</h2>
              <div className="space-y-5">
                <div>
                  <label className="form-label">Preferred Pickup Time <span className="text-red-600">*</span></label>
                  <input type="datetime-local" value={pickupTime} onChange={(e) => setPickupTime(e.target.value)} className="input-field" />
                </div>
                <div>
                  <label className="form-label">Notes</label>
                  <textarea rows={4} placeholder="Add any special requests or notes for the donor..." value={notes} onChange={(e) => setNotes(e.target.value)} className="input-field resize-none" />
                </div>
                <div className="privacy-option">
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input type="checkbox" checked={discreetPickup} onChange={(e) => setDiscreetPickup(e.target.checked)} className="mt-1 w-4 h-4" />
                    <div>
                      <div className="privacy-label">Request discreet pickup</div>
                      <div className="privacy-desc">Donor will provide pickup instructions privately after approval</div>
                    </div>
                  </label>
                </div>
                <button onClick={handleSubmit} className="btn-primary w-full">Send Pickup Request</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function CreateDonation({ onBack, onSubmit }: { onBack: () => void; onSubmit: any }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [foodType, setFoodType] = useState('');
  const [quantity, setQuantity] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [dietaryTags, setDietaryTags] = useState<DietaryTag[]>([]);
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [hideAddress, setHideAddress] = useState(true);
  const [allowDiscreet, setAllowDiscreet] = useState(false);
  const [imageData, setImageData] = useState<string | null>(null);
  const [imageError, setImageError] = useState<string | null>(null);

  const handleImage = async (file: File | undefined) => {
    setImageError(null);
    if (!file) { setImageData(null); return; }
    if (!file.type.startsWith('image/')) { setImageError('Please select an image file'); return; }
    if (file.size > 4 * 1024 * 1024) { setImageError('Image must be under 4MB'); return; }
    try { setImageData(await readFileAsDataUrl(file)); }
    catch { setImageError('Could not read image'); }
  };

  const handleSubmit = () => {
    if (!title || !description || !foodType || !quantity || !expiryDate || !city || !address) {
      alert('Please fill in all required fields');
      return;
    }
    const payload: any = { title, description, foodType, quantity, expiryDate, dietaryTags, city, address, hideAddress, allowDiscreet };
    if (imageData) payload.image = { data: imageData };
    onSubmit(payload);
  };

  return (
    <div>
      <div className="mb-8">
        <div className="eyebrow mb-2">New listing</div>
        <h1 className="page-title">Share surplus food.</h1>
        <p className="page-subtitle">A few details and your neighbors can reserve it within minutes.</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
        <div className="card space-y-5">
          <div><label className="form-label">Donation Title <span className="text-red-600">*</span></label><input type="text" placeholder="e.g., Fresh Vegetables" value={title} onChange={(e) => setTitle(e.target.value)} className="input-field" /></div>
          <div><label className="form-label">Description <span className="text-red-600">*</span></label><textarea rows={4} placeholder="Describe the food items..." value={description} onChange={(e) => setDescription(e.target.value)} className="input-field resize-none" /></div>
          <div>
            <label className="form-label">Food Type <span className="text-red-600">*</span></label>
            <select value={foodType} onChange={(e) => setFoodType(e.target.value)} className="input-field">
              <option value="">Select food type</option>
              {['Produce', 'Prepared Food', 'Baked Goods', 'Non-Perishable', 'Dairy', 'Meat & Seafood'].map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="form-label">Quantity <span className="text-red-600">*</span></label><input type="text" placeholder="e.g., 5 kg" value={quantity} onChange={(e) => setQuantity(e.target.value)} className="input-field" /></div>
            <div><label className="form-label">Expiry Date <span className="text-red-600">*</span></label><input type="datetime-local" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} className="input-field" /></div>
          </div>
          <div>
            <label className="form-label mb-3">Dietary Tags</label>
            <div className="grid grid-cols-2 gap-3">
              {(['vegan', 'vegetarian', 'gluten_free', 'kosher'] as DietaryTag[]).map((tag) => (
                <label key={tag} className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={dietaryTags.includes(tag)} onChange={() => setDietaryTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag])} className="w-4 h-4" />
                  <span className="form-checkbox-label">{tag === 'gluten_free' ? 'Gluten-Free' : tag.charAt(0).toUpperCase() + tag.slice(1)}</span>
                </label>
              ))}
            </div>
          </div>
          <div><label className="form-label">Pickup City <span className="text-red-600">*</span></label><input type="text" placeholder="Enter city" value={city} onChange={(e) => setCity(e.target.value)} className="input-field" /></div>
          <div><label className="form-label">Pickup Address <span className="text-red-600">*</span></label><input type="text" placeholder="Street address" value={address} onChange={(e) => setAddress(e.target.value)} className="input-field" /></div>
        </div>
        <div className="space-y-6">
          <div className="card">
            <label className="form-label mb-3">Upload Image</label>
            <label className="upload-area cursor-pointer block">
              {imageData ? (
                <img src={imageData} alt="Preview" className="max-h-48 mx-auto rounded" />
              ) : (
                <>
                  <span className="text-6xl mb-3 block text-center">📷</span>
                  <div className="upload-text text-center">Click to upload</div>
                  <div className="upload-hint text-center">PNG, JPG up to 4MB</div>
                </>
              )}
              <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImage(e.target.files?.[0])} />
            </label>
            {imageData && (
              <button type="button" onClick={() => setImageData(null)} className="mt-2 text-xs text-red-600 underline">Remove image</button>
            )}
            {imageError && <div className="mt-2 text-xs text-red-600">{imageError}</div>}
          </div>
          <div className="card">
            <label className="form-label mb-4">Privacy Options</label>
            <div className="space-y-3">
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={hideAddress} onChange={(e) => setHideAddress(e.target.checked)} className="mt-1 w-4 h-4" />
                <div><div className="privacy-label">Hide exact address until request approved</div><div className="privacy-desc">Only city and area shown publicly</div></div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={allowDiscreet} onChange={(e) => setAllowDiscreet(e.target.checked)} className="mt-1 w-4 h-4" />
                <div><div className="privacy-label">Allow discreet pickup requests</div><div className="privacy-desc">Recipients can request private pickup instructions</div></div>
              </label>
            </div>
          </div>
          <div className="flex gap-4">
            <button onClick={onBack} className="btn-secondary flex-1">Cancel</button>
            <button onClick={handleSubmit} className="btn-primary flex-1">Publish Donation</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function MyDonations({ donations, requests, users, onViewDetails, onDelete, onEdit, onApprove, onDecline, onSetStatus }: any) {
  const formatDateTime = (iso: string) => new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  const getDonationRequests = (did: number) => requests.filter((r: any) => r.donationId === did);

  return (
    <div>
      <div className="mb-8">
        <div className="eyebrow mb-2">Donor dashboard</div>
        <h1 className="page-title">My donations.</h1>
        <p className="page-subtitle">Track your active listings and respond to incoming pickup requests.</p>
      </div>
      {donations.length === 0 ? <EmptyState message="You haven't created any donations yet. Share something delicious!" /> : (
        <div className="space-y-5">
          {donations.map((d: any) => {
            const dreqs = getDonationRequests(d.id);
            const pendingCount = dreqs.filter((r: any) => r.status === 'pending').length;
            const expiry = expiryHint(d.expiryDate);
            const isAvailable = d.status === 'available';
            const isReserved = d.status === 'reserved';
            const isClosed = d.status === 'cancelled' || d.status === 'expired';
            return (
              <div key={d.id} className="donation-row">
                <div className="grid grid-cols-1 md:grid-cols-12">
                  <div className="md:col-span-3 row-thumb">
                    <div className="row-thumb-inner">
                      <DonationImage url={d.imageUrl} foodType={d.foodType} seedId={d.id} />
                    </div>
                    <div className="image-badge"><StatusBadge status={d.status} /></div>
                  </div>
                  <div className="md:col-span-6 row-body">
                    <div className="mb-4">
                      <div className="eyebrow mb-1">{d.foodType}</div>
                      <h3 className="row-title">{d.title}</h3>
                      <div className="row-meta">{d.city}</div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 mb-4">
                      <span className="info-pill"><span className="info-pill-label">Quantity</span><span className="info-pill-value">{d.quantity}</span></span>
                      <span className="info-pill"><span className="info-pill-label">Expires</span><span className="info-pill-value">{formatDateTime(d.expiryDate)}</span></span>
                      <span className="info-pill"><span className="info-pill-label">Requests</span><span className="info-pill-value">{dreqs.length}</span></span>
                      {expiry && isAvailable && (
                        <span className={`expiry-pill ${expiry.soon ? 'is-soon' : ''}`}>⏱ {expiry.label}</span>
                      )}
                    </div>
                    {pendingCount > 0 && <div className="alert-pending mb-4">⚠️ {pendingCount} pending request{pendingCount > 1 ? 's' : ''} awaiting your response</div>}
                    {dreqs.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-zinc-100">
                        <div className="detail-label mb-3">Incoming requests</div>
                        <div className="space-y-3">
                          {dreqs.map((r: any) => {
                            const requester = users.find((u: any) => u.id === r.requesterId);
                            return (
                              <div key={r.id} className="incoming-request">
                                <div className="flex items-start gap-3">
                                  <div className="requester-avatar">👤</div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-start justify-between gap-3 flex-wrap">
                                      <div>
                                        <div className="font-semibold text-[14px] text-[#1c3520]">{requester?.displayName ?? `User #${r.requesterId}`}</div>
                                        <div className="text-[13px] text-[#4b5d4d] mt-0.5">Pickup · {formatDateTime(r.pickupTime)}</div>
                                      </div>
                                      <StatusBadge status={r.status} />
                                    </div>
                                    {r.notes && <div className="text-[13px] text-[#4b5d4d] mt-2 leading-relaxed">{r.notes}</div>}
                                    {r.discreetPickup && <span className="privacy-badge mt-2">🔒 Discreet pickup requested</span>}
                                    {r.status === 'pending' && (
                                      <div className="flex gap-2 mt-3">
                                        <button onClick={() => onApprove(r.id)} className="btn-primary text-[13px] py-1.5 px-3">Approve</button>
                                        <button onClick={() => { if (confirm('Decline this request?')) onDecline(r.id); }} className="btn-danger text-[13px] py-1.5 px-3">Decline</button>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="md:col-span-3 row-actions">
                    <div className="action-stack-label">Primary</div>
                    {isClosed ? (
                      <button onClick={() => onSetStatus(d.id, 'available')} className="btn-primary">Reopen listing</button>
                    ) : (
                      <button onClick={() => onViewDetails(d.id)} className="btn-primary">View details</button>
                    )}
                    <button onClick={() => onEdit(d.id)} className="btn-secondary">Edit listing</button>
                    {(isAvailable || isReserved) && (
                      <>
                        <div className="action-stack-divider" />
                        <div className="action-stack-label">Manage</div>
                        {isAvailable && (
                          <>
                            <button onClick={() => { if (confirm('Cancel this donation? Open requests stay unaffected.')) onSetStatus(d.id, 'cancelled'); }} className="btn-ghost">Cancel listing</button>
                            <button onClick={() => { if (confirm('Mark this donation as expired?')) onSetStatus(d.id, 'expired'); }} className="btn-ghost">Mark expired</button>
                          </>
                        )}
                        {isReserved && (
                          <button onClick={() => { if (confirm('Cancel this reserved donation? All open pickup requests will be cancelled.')) onSetStatus(d.id, 'cancelled'); }} className="btn-ghost">Cancel & release</button>
                        )}
                      </>
                    )}
                    <div className="mt-auto pt-2">
                      <button onClick={() => { if (confirm('Are you sure you want to delete this donation?')) onDelete(d.id); }} className="btn-danger w-full">Delete listing</button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function EditDonation({ donation, onBack, onSubmit }: { donation: Donation; onBack: () => void; onSubmit: (patch: Partial<Donation> & { image?: { data: string } }) => void; }) {
  const [title, setTitle] = useState(donation.title);
  const [description, setDescription] = useState(donation.description);
  const [foodType, setFoodType] = useState(donation.foodType);
  const [quantity, setQuantity] = useState(donation.quantity);
  const [expiryDate, setExpiryDate] = useState(donation.expiryDate);
  const [dietaryTags, setDietaryTags] = useState<DietaryTag[]>(donation.dietaryTags);
  const [city, setCity] = useState(donation.city);
  const [address, setAddress] = useState<string>(donation.address ?? '');
  const [hideAddress, setHideAddress] = useState(!!donation.hideAddress);
  const [allowDiscreet, setAllowDiscreet] = useState(!!donation.allowDiscreet);
  const [newImageData, setNewImageData] = useState<string | null>(null);
  const [imageError, setImageError] = useState<string | null>(null);

  const handleImage = async (file: File | undefined) => {
    setImageError(null);
    if (!file) { setNewImageData(null); return; }
    if (!file.type.startsWith('image/')) { setImageError('Please select an image file'); return; }
    if (file.size > 4 * 1024 * 1024) { setImageError('Image must be under 4MB'); return; }
    try { setNewImageData(await readFileAsDataUrl(file)); }
    catch { setImageError('Could not read image'); }
  };

  const handleSubmit = () => {
    if (!title || !description || !foodType || !quantity || !expiryDate || !city || !address) {
      alert('Please fill in all required fields');
      return;
    }
    const payload: any = { title, description, foodType, quantity, expiryDate, dietaryTags, city, address, hideAddress, allowDiscreet };
    if (newImageData) payload.image = { data: newImageData };
    onSubmit(payload);
  };

  return (
    <div>
      <div className="breadcrumb"><button onClick={onBack} className="breadcrumb-link">My Donations</button><span>/</span><span className="breadcrumb-current">Edit Donation</span></div>
      <div className="mb-8">
        <div className="eyebrow mb-2">Edit listing</div>
        <h1 className="page-title">Update your donation.</h1>
        <p className="page-subtitle">Refresh the details so neighbors see the latest information.</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
        <div className="card space-y-5">
          <div><label className="form-label">Donation Title <span className="text-red-600">*</span></label><input type="text" value={title} onChange={(e) => setTitle(e.target.value)} className="input-field" /></div>
          <div><label className="form-label">Description <span className="text-red-600">*</span></label><textarea rows={4} value={description} onChange={(e) => setDescription(e.target.value)} className="input-field resize-none" /></div>
          <div>
            <label className="form-label">Food Type <span className="text-red-600">*</span></label>
            <select value={foodType} onChange={(e) => setFoodType(e.target.value)} className="input-field">
              <option value="">Select food type</option>
              {['Produce', 'Prepared Food', 'Baked Goods', 'Non-Perishable', 'Dairy', 'Meat & Seafood'].map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="form-label">Quantity <span className="text-red-600">*</span></label><input type="text" value={quantity} onChange={(e) => setQuantity(e.target.value)} className="input-field" /></div>
            <div><label className="form-label">Expiry Date <span className="text-red-600">*</span></label><input type="datetime-local" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} className="input-field" /></div>
          </div>
          <div>
            <label className="form-label mb-3">Dietary Tags</label>
            <div className="grid grid-cols-2 gap-3">
              {(['vegan', 'vegetarian', 'gluten_free', 'kosher'] as DietaryTag[]).map((tag) => (
                <label key={tag} className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={dietaryTags.includes(tag)} onChange={() => setDietaryTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag])} className="w-4 h-4" />
                  <span className="form-checkbox-label">{tag === 'gluten_free' ? 'Gluten-Free' : tag.charAt(0).toUpperCase() + tag.slice(1)}</span>
                </label>
              ))}
            </div>
          </div>
          <div><label className="form-label">Pickup City <span className="text-red-600">*</span></label><input type="text" value={city} onChange={(e) => setCity(e.target.value)} className="input-field" /></div>
          <div><label className="form-label">Pickup Address <span className="text-red-600">*</span></label><input type="text" value={address} onChange={(e) => setAddress(e.target.value)} className="input-field" /></div>
        </div>
        <div className="space-y-6">
          <div className="card">
            <label className="form-label mb-3">Image</label>
            {donation.imageUrl && !newImageData && (
              <div className="mb-3">
                <div className="text-xs text-zinc-500 mb-1">Current image</div>
                <img src={donation.imageUrl} alt="Current" className="max-h-32 rounded" />
              </div>
            )}
            <label className="upload-area cursor-pointer block">
              {newImageData ? (
                <img src={newImageData} alt="New preview" className="max-h-48 mx-auto rounded" />
              ) : (
                <>
                  <span className="text-6xl mb-3 block text-center">📷</span>
                  <div className="upload-text text-center">Click to upload new image</div>
                  <div className="upload-hint text-center">PNG, JPG up to 4MB</div>
                </>
              )}
              <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImage(e.target.files?.[0])} />
            </label>
            {newImageData && (
              <button type="button" onClick={() => setNewImageData(null)} className="mt-2 text-xs text-red-600 underline">Discard new image</button>
            )}
            {imageError && <div className="mt-2 text-xs text-red-600">{imageError}</div>}
          </div>
          <div className="card">
            <label className="form-label mb-4">Privacy Options</label>
            <div className="space-y-3">
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={hideAddress} onChange={(e) => setHideAddress(e.target.checked)} className="mt-1 w-4 h-4" />
                <div><div className="privacy-label">Hide exact address until request approved</div><div className="privacy-desc">Only city and area shown publicly</div></div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={allowDiscreet} onChange={(e) => setAllowDiscreet(e.target.checked)} className="mt-1 w-4 h-4" />
                <div><div className="privacy-label">Allow discreet pickup requests</div><div className="privacy-desc">Recipients can request private pickup instructions</div></div>
              </label>
            </div>
          </div>
          <div className="flex gap-4">
            <button onClick={onBack} className="btn-secondary flex-1">Cancel</button>
            <button onClick={handleSubmit} className="btn-primary flex-1">Save Changes</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function MyRequests({ requests, donations, users, onViewDonation, onUpdateStatus, onLeaveReview, reviews }: any) {
  const [activeTab, setActiveTab] = useState<'all' | RequestStatus>('all');
  const formatDateTime = (iso: string) => new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  const filteredRequests = activeTab === 'all' ? requests : requests.filter((r: any) => r.status === activeTab);
  const hasReview = (rid: number) => reviews.some((r: any) => r.requestId === rid);
  const tabCount = (tab: 'all' | RequestStatus) => tab === 'all' ? requests.length : requests.filter((r: any) => r.status === tab).length;

  return (
    <div>
      <div className="mb-8">
        <div className="eyebrow mb-2">Recipient dashboard</div>
        <h1 className="page-title">My requests.</h1>
        <p className="page-subtitle">Follow your reservations from request to pickup.</p>
      </div>
      <div className="tab-bar overflow-x-auto max-w-full">
        {(['all', 'pending', 'approved', 'completed', 'cancelled'] as const).map((tab) => (
          <button key={tab} onClick={() => setActiveTab(tab)} className={`tab-button ${activeTab === tab ? 'tab-active' : ''} whitespace-nowrap`}>
            {tab} <span className="opacity-70 font-normal">{tabCount(tab)}</span>
          </button>
        ))}
      </div>
      {filteredRequests.length === 0 ? <EmptyState message={`No ${activeTab !== 'all' ? activeTab : ''} requests found`} /> : (
        <div className="space-y-5">
          {filteredRequests.map((req: any) => {
            const donation = donations.find((d: any) => d.id === req.donationId);
            const donor = donation ? users.find((u: any) => u.id === donation.donorId) : null;
            if (!donation || !donor) return null;
            const canSeeAddress = req.status === 'approved' || req.status === 'completed';
            const reviewed = hasReview(req.id);
            return (
              <div key={req.id} className={`request-row state-${req.status}`}>
                <div className="grid grid-cols-1 md:grid-cols-12">
                  <div className="md:col-span-3 row-thumb">
                    <div className="row-thumb-inner">
                      <DonationImage url={donation.imageUrl} foodType={donation.foodType} seedId={donation.id} />
                    </div>
                    <div className="image-badge"><StatusBadge status={req.status} /></div>
                  </div>
                  <div className="md:col-span-6 row-body">
                    <div className="mb-4">
                      <div className="eyebrow mb-1">{donation.foodType}</div>
                      <h3 className="row-title">{donation.title}</h3>
                      <div className="row-meta">From <span className="font-semibold text-[#1c3520]">{donor.displayName}</span></div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 mb-3">
                      <span className="info-pill"><span className="info-pill-label">Pickup</span><span className="info-pill-value">{formatDateTime(req.pickupTime)}</span></span>
                      <span className="info-pill"><span className="info-pill-label">📍</span><span className="info-pill-value">{canSeeAddress ? `${donation.address}, ${donation.city}` : donation.city}</span></span>
                      {req.discreetPickup && <span className="privacy-badge">🔒 Discreet</span>}
                    </div>
                    {!canSeeAddress && req.status === 'pending' && (
                      <div className="text-[12.5px] text-[#8a9b8c] mb-2">Full address shared after the donor approves your request.</div>
                    )}
                    {req.notes && (
                      <div className="mt-3 pt-3 border-t border-zinc-100">
                        <div className="detail-label mb-1">Your notes</div>
                        <div className="text-[14px] text-[#1c3520] leading-relaxed">{req.notes}</div>
                      </div>
                    )}
                  </div>
                  <div className="md:col-span-3 row-actions">
                    {req.status === 'pending' && (
                      <>
                        <div className="status-pending-badge">⏳ Waiting for approval</div>
                        <button onClick={() => onViewDonation(donation.id)} className="btn-secondary">View donation</button>
                        <div className="action-stack-divider" />
                        <button onClick={() => confirm('Cancel this request?') && onUpdateStatus(req.id, 'cancelled')} className="btn-ghost">Cancel request</button>
                      </>
                    )}
                    {req.status === 'approved' && (
                      <>
                        <div className="action-stack-label">Next step</div>
                        <button onClick={() => confirm('Mark this pickup as completed?') && onUpdateStatus(req.id, 'completed')} className="btn-primary">Mark picked up</button>
                        <button onClick={() => onViewDonation(donation.id)} className="btn-secondary">View donation</button>
                        <div className="action-stack-divider" />
                        <button onClick={() => confirm('Cancel this request?') && onUpdateStatus(req.id, 'cancelled')} className="btn-ghost">Cancel</button>
                      </>
                    )}
                    {req.status === 'completed' && (
                      <>
                        {!reviewed ? (
                          <>
                            <div className="action-stack-label">Share feedback</div>
                            <button onClick={() => onLeaveReview(req.id)} className="btn-accent">Leave review</button>
                          </>
                        ) : (
                          <div className="status-completed-badge">✓ Review submitted</div>
                        )}
                        <button onClick={() => onViewDonation(donation.id)} className="btn-secondary">View donation</button>
                      </>
                    )}
                    {req.status === 'cancelled' && (
                      <button onClick={() => onViewDonation(donation.id)} className="btn-secondary">View donation</button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ReviewRating({ request, donation, donor, onBack, onSubmit }: any) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState('');

  return (
    <div>
      <div className="breadcrumb"><button onClick={onBack} className="breadcrumb-link">My Requests</button><span>/</span><span className="breadcrumb-current">Leave Review</span></div>
      <div className="max-w-2xl mx-auto">
        <div className="card">
          <h1 className="review-title mb-6">Leave a Review</h1>
          <div className="review-donation-info">
            <div className="detail-label mb-1">Donation</div>
            <div className="review-donation-title">{donation.title}</div>
            <div className="card-meta mt-2">Donor: <span className="card-value">{donor.displayName}</span></div>
          </div>
          <div className="space-y-6">
            <div>
              <label className="form-label mb-3">Rating <span className="text-red-600">*</span></label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button key={star} onClick={() => setRating(star)} onMouseEnter={() => setHoveredRating(star)} onMouseLeave={() => setHoveredRating(0)} className="star-button" style={{ fontSize: '2.5rem', color: star <= (hoveredRating || rating) ? '#e07a3c' : '#d4d4d8' }}>
                    ⭐
                  </button>
                ))}
              </div>
            </div>
            <div><label className="form-label mb-2">Comment</label><textarea rows={6} placeholder="Share your experience with this donation and donor..." value={comment} onChange={(e) => setComment(e.target.value)} className="input-field resize-none" /></div>
            <div className="flex gap-4">
              <button onClick={onBack} className="btn-secondary flex-1">Cancel</button>
              <button onClick={() => { if (rating === 0) { alert('Please select a rating'); return; } onSubmit(rating, comment); }} className="btn-primary flex-1">Submit Review</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Profile({ user, onBack }: any) {
  const [displayName, setDisplayName] = useState(user.displayName);
  const [email, setEmail] = useState(user.email);
  const [phone, setPhone] = useState(user.phone);
  const [dietaryPreferences, setDietaryPreferences] = useState<DietaryTag[]>(user.dietaryPreferences);
  const [discreetPickup, setDiscreetPickup] = useState(user.discreetPickup);

  return (
    <div>
      <div className="mb-8">
        <div className="eyebrow mb-2">Your account</div>
        <h1 className="page-title">Profile & preferences</h1>
        <p className="page-subtitle">Manage how the community sees and reaches you.</p>
      </div>
      <div className="max-w-2xl">
        <div className="profile-reputation">
          <div className="flex items-center gap-5">
            <div className="donor-avatar-large">👤</div>
            <div className="flex-1">
              <div className="eyebrow mb-1">Community reputation</div>
              <div className="donor-name text-xl">{user.displayName}</div>
              <div className="flex items-center gap-1 text-sm mt-1">
                {[...Array(5)].map((_, i) => <span key={i} className={i < Math.floor(user.rating) ? 'star-filled' : 'star-empty'}>⭐</span>)}
                <span className="rating-value ml-2">{user.rating.toFixed(1)}</span>
                <span className="rating-count">({user.reviewCount} reviews)</span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 mt-5">
            <div className="stat-tile"><div className="stat-value">{user.rating.toFixed(1)}</div><div className="stat-label">Rating</div></div>
            <div className="stat-tile"><div className="stat-value">{user.reviewCount}</div><div className="stat-label">Reviews</div></div>
            <div className="stat-tile"><div className="stat-value">{user.dietaryPreferences.length}</div><div className="stat-label">Preferences</div></div>
          </div>
        </div>
        <div className="card p-6 mb-6"><h2 className="section-title mb-4">Personal information</h2><div className="space-y-4"><div><label className="form-label mb-2">Display Name</label><input type="text" value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="input-field" /></div><div><label className="form-label mb-2">Email</label><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="input-field" /></div><div><label className="form-label mb-2">Phone</label><input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="input-field" /></div></div></div>
        <div className="card p-6 mb-6"><h2 className="section-title mb-4">Dietary preferences</h2><div className="grid grid-cols-2 gap-3">{(['vegan', 'vegetarian', 'gluten_free', 'kosher'] as DietaryTag[]).map((tag) => (<label key={tag} className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={dietaryPreferences.includes(tag)} onChange={() => setDietaryPreferences(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag])} className="w-4 h-4" /><span className="form-checkbox-label">{tag === 'gluten_free' ? 'Gluten-Free' : tag.charAt(0).toUpperCase() + tag.slice(1)}</span></label>))}</div></div>
        <div className="card p-6 mb-6"><h2 className="section-title mb-4">Privacy settings</h2><label className="flex items-start gap-3 cursor-pointer"><input type="checkbox" checked={discreetPickup} onChange={(e) => setDiscreetPickup(e.target.checked)} className="mt-1 w-4 h-4" /><div><div className="privacy-label">Prefer discreet pickups</div><div className="privacy-desc mt-1">When enabled, your pickup requests will default to discreet mode</div></div></label></div>
        <div className="flex gap-4"><button onClick={onBack} className="btn-secondary flex-1">Cancel</button><button onClick={() => { alert('Profile updated (mock action)'); onBack(); }} className="btn-primary flex-1">Save changes</button></div>
      </div>
    </div>
  );
}