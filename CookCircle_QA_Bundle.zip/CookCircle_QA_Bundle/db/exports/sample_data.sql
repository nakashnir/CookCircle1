--
-- PostgreSQL database dump
--
--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--
INSERT INTO public.users (id, display_name, email, phone, dietary_preferences, discreet_pickup, rating, review_count, created_at) VALUES (2, 'Maria Garcia', 'maria@example.com', '555-0102', '["vegan"]', true, 4.9, 47, '2026-04-22 21:18:44.018213+00');
INSERT INTO public.users (id, display_name, email, phone, dietary_preferences, discreet_pickup, rating, review_count, created_at) VALUES (3, 'John Smith', 'john@example.com', '555-0103', '[]', false, 4.6, 18, '2026-04-22 21:18:44.018213+00');
INSERT INTO public.users (id, display_name, email, phone, dietary_preferences, discreet_pickup, rating, review_count, created_at) VALUES (4, 'Sarah Johnson', 'sarah@example.com', '555-0104', '["gluten_free"]', false, 5, 31, '2026-04-22 21:18:44.018213+00');
INSERT INTO public.users (id, display_name, email, phone, dietary_preferences, discreet_pickup, rating, review_count, created_at) VALUES (5, 'David Lee', 'david@example.com', '555-0105', '[]', false, 4.7, 15, '2026-04-22 21:18:44.018213+00');
INSERT INTO public.users (id, display_name, email, phone, dietary_preferences, discreet_pickup, rating, review_count, created_at) VALUES (1, 'Alex Chen', 'alex@example.com', '555-0101', '["vegetarian"]', false, 5, 1, '2026-04-22 21:18:44.018213+00');
--
-- Data for Name: donations; Type: TABLE DATA; Schema: public; Owner: -
--
INSERT INTO public.donations (id, donor_id, title, description, food_type, quantity, expiry_date, dietary_tags, city, address, latitude, longitude, image_url, image_public_id, status, hide_address, allow_discreet, created_at) VALUES (6, 1, 'Garden Herbs', 'Fresh basil, mint, parsley, and rosemary from my home garden. Pick what you need.', 'Produce', 'Several bunches', '2026-04-25T18:00', '["vegan", "gluten_free"]', 'Downtown', '12 Garden Lane', 37.745098, -122.467255, 'https://picsum.photos/seed/Garden%20Herbs/640/480', 'local/Garden%20Herbs', 'available', true, true, '2026-04-22 21:18:44.018213+00');
INSERT INTO public.donations (id, donor_id, title, description, food_type, quantity, expiry_date, dietary_tags, city, address, latitude, longitude, image_url, image_public_id, status, hide_address, allow_discreet, created_at) VALUES (1, 2, 'Fresh Vegetables', 'Mixed fresh vegetables including tomatoes, cucumbers, lettuce, and carrots. All organic and locally grown.', 'Produce', '5 kg', '2026-04-22T18:00', '["vegan"]', 'Downtown', '123 Main Street', 37.734118, -122.430784, 'https://picsum.photos/seed/Fresh%20Vegetables/640/480', 'local/Fresh%20Vegetables', 'reserved', true, false, '2026-04-22 21:18:44.018213+00');
INSERT INTO public.donations (id, donor_id, title, description, food_type, quantity, expiry_date, dietary_tags, city, address, latitude, longitude, image_url, image_public_id, status, hide_address, allow_discreet, created_at) VALUES (2, 3, 'Homemade Pasta', 'Fresh homemade pasta with tomato sauce. Made this morning, perfect for a quick meal.', 'Prepared Food', '10 portions', '2026-04-20T20:00', '["vegetarian"]', 'West End', '456 Oak Avenue', 37.781961, -122.417059, 'https://picsum.photos/seed/Homemade%20Pasta/640/480', 'local/Homemade%20Pasta', 'available', true, true, '2026-04-22 21:18:44.018213+00');
INSERT INTO public.donations (id, donor_id, title, description, food_type, quantity, expiry_date, dietary_tags, city, address, latitude, longitude, image_url, image_public_id, status, hide_address, allow_discreet, created_at) VALUES (3, 4, 'Bread & Pastries', 'Assorted bread and pastries from my bakery. All baked fresh this morning.', 'Baked Goods', '20 items', '2026-04-19T22:00', '["vegetarian"]', 'City Center', '789 Bakery Lane', 37.789804, -122.384118, 'https://picsum.photos/seed/Bread%20%26%20Pastries/640/480', 'local/Bread%20%26%20Pastries', 'picked_up', true, false, '2026-04-22 21:18:44.018213+00');
INSERT INTO public.donations (id, donor_id, title, description, food_type, quantity, expiry_date, dietary_tags, city, address, latitude, longitude, image_url, image_public_id, status, hide_address, allow_discreet, created_at) VALUES (4, 5, 'Canned Goods', 'Various canned vegetables and beans. Non-perishable, great for stocking up.', 'Non-Perishable', '15 cans', '2027-04-18T23:59', '["vegan", "gluten_free"]', 'East Side', '321 Elm Street', 37.780784, -122.46098, 'https://picsum.photos/seed/Canned%20Goods/640/480', 'local/Canned%20Goods', 'available', true, false, '2026-04-22 21:18:44.018213+00');
INSERT INTO public.donations (id, donor_id, title, description, food_type, quantity, expiry_date, dietary_tags, city, address, latitude, longitude, image_url, image_public_id, status, hide_address, allow_discreet, created_at) VALUES (5, 2, 'Fresh Fruit', 'Apples, bananas, and oranges. Slightly overripe but perfect for smoothies or baking.', 'Produce', '3 kg', '2026-04-21T18:00', '["vegan"]', 'North District', '555 Apple Road', 37.800784, -122.37902, 'https://picsum.photos/seed/Fresh%20Fruit/640/480', 'local/Fresh%20Fruit', 'available', true, false, '2026-04-22 21:18:44.018213+00');
INSERT INTO public.donations (id, donor_id, title, description, food_type, quantity, expiry_date, dietary_tags, city, address, latitude, longitude, image_url, image_public_id, status, hide_address, allow_discreet, created_at) VALUES (7, 1, 'Lentil Soup (Family Batch)', 'Big pot of lentil soup with carrots and celery. Already cooled, easy to reheat.', 'Prepared Food', '8 portions', '2026-04-23T20:00', '["vegan", "vegetarian"]', 'Downtown', '12 Garden Lane', 37.745098, -122.467255, 'https://picsum.photos/seed/Lentil%20Soup%20(Family%20Batch)/640/480', 'local/Lentil%20Soup%20(Family%20Batch)', 'available', true, false, '2026-04-22 21:18:44.018213+00');
--
-- Data for Name: pickup_requests; Type: TABLE DATA; Schema: public; Owner: -
--
INSERT INTO public.pickup_requests (id, donation_id, requester_id, pickup_time, notes, discreet_pickup, status, created_at) VALUES (1, 1, 1, '2026-04-19T14:00', 'Please ring doorbell', false, 'approved', '2026-04-22 21:18:44.018213+00');
INSERT INTO public.pickup_requests (id, donation_id, requester_id, pickup_time, notes, discreet_pickup, status, created_at) VALUES (2, 2, 1, '2026-04-20T16:30', '', false, 'pending', '2026-04-22 21:18:44.018213+00');
INSERT INTO public.pickup_requests (id, donation_id, requester_id, pickup_time, notes, discreet_pickup, status, created_at) VALUES (3, 3, 1, '2026-04-18T10:00', 'Back entrance pickup', true, 'completed', '2026-04-22 21:18:44.018213+00');
INSERT INTO public.pickup_requests (id, donation_id, requester_id, pickup_time, notes, discreet_pickup, status, created_at) VALUES (4, 6, 3, '2026-04-22T17:00', 'Would love to grab the basil if possible!', false, 'cancelled', '2026-04-22 21:18:44.018213+00');
--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--
INSERT INTO public.reviews (id, donation_id, request_id, reviewer_id, reviewee_id, rating, comment, created_at) VALUES (1, 3, 3, 1, 4, 5, 'Great quality pastries! Sarah was very kind and helpful.', '2026-04-22 21:18:44.018213+00');
--
-- Name: donations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--
--
-- Name: pickup_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--
--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--
--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--
--
-- PostgreSQL database dump complete
--
