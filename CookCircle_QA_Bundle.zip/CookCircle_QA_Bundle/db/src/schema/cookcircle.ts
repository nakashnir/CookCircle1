import {
  pgTable,
  serial,
  text,
  varchar,
  integer,
  boolean,
  timestamp,
  jsonb,
  pgEnum,
  uniqueIndex,
  doublePrecision,
} from "drizzle-orm/pg-core";

export const donationStatusEnum = pgEnum("donation_status", [
  "available",
  "reserved",
  "picked_up",
  "cancelled",
  "expired",
]);

export const requestStatusEnum = pgEnum("request_status", [
  "pending",
  "approved",
  "cancelled",
  "completed",
]);

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  displayName: varchar("display_name", { length: 120 }).notNull(),
  email: varchar("email", { length: 160 }).notNull().unique(),
  phone: varchar("phone", { length: 40 }).notNull().default(""),
  dietaryPreferences: jsonb("dietary_preferences")
    .$type<string[]>()
    .notNull()
    .default([]),
  discreetPickup: boolean("discreet_pickup").notNull().default(false),
  rating: doublePrecision("rating").notNull().default(0),
  reviewCount: integer("review_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const donationsTable = pgTable("donations", {
  id: serial("id").primaryKey(),
  donorId: integer("donor_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull(),
  foodType: varchar("food_type", { length: 80 }).notNull(),
  quantity: varchar("quantity", { length: 80 }).notNull(),
  expiryDate: varchar("expiry_date", { length: 40 }).notNull(),
  dietaryTags: jsonb("dietary_tags").$type<string[]>().notNull().default([]),
  city: varchar("city", { length: 120 }).notNull(),
  address: varchar("address", { length: 240 }).notNull(),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  imageUrl: text("image_url"),
  imagePublicId: text("image_public_id"),
  status: donationStatusEnum("status").notNull().default("available"),
  hideAddress: boolean("hide_address").notNull().default(true),
  allowDiscreet: boolean("allow_discreet").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const pickupRequestsTable = pgTable("pickup_requests", {
  id: serial("id").primaryKey(),
  donationId: integer("donation_id")
    .notNull()
    .references(() => donationsTable.id, { onDelete: "cascade" }),
  requesterId: integer("requester_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  pickupTime: varchar("pickup_time", { length: 40 }).notNull(),
  notes: text("notes").notNull().default(""),
  discreetPickup: boolean("discreet_pickup").notNull().default(false),
  status: requestStatusEnum("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const reviewsTable = pgTable(
  "reviews",
  {
    id: serial("id").primaryKey(),
    donationId: integer("donation_id")
      .notNull()
      .references(() => donationsTable.id, { onDelete: "cascade" }),
    requestId: integer("request_id")
      .notNull()
      .references(() => pickupRequestsTable.id, { onDelete: "cascade" }),
    reviewerId: integer("reviewer_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    revieweeId: integer("reviewee_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    rating: integer("rating").notNull(),
    comment: text("comment").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => ({
    uniqueReviewPerRequest: uniqueIndex("reviews_request_unique").on(
      t.requestId,
    ),
  }),
);

export type User = typeof usersTable.$inferSelect;
export type Donation = typeof donationsTable.$inferSelect;
export type PickupRequest = typeof pickupRequestsTable.$inferSelect;
export type Review = typeof reviewsTable.$inferSelect;
