# CookCircle — QA Index

> Generated: April 25, 2026
> Bundle contents: full source (frontend + backend + DB schema), schema export, sample data export, architecture config.

---

## 1. Project Overview

CookCircle is an **academic MVP** for community food donation and sharing.

**Core scope (locked):**
- Donation lifecycle (`available → reserved → picked_up / cancelled / expired`)
- Pickup requests with approval/decline/complete flow
- Reviews & ratings (one per completed pickup, unique `(request_id, reviewer_id)`)
- Dietary tags filter on the feed
- Privacy / discreet pickup gating (full address only revealed after approval)
- Media integration (Cloudinary or local fallback)
- Location integration (Mapbox / Google Maps or local fallback)
- Postgres-backed backend with Drizzle ORM

**Explicitly out of scope:** chat, AI features, shared cooking, admin panel, payments, delivery logistics, push notifications, gamification, new authentication.

---

## 2. Project Structure

```
CookCircle_QA_Bundle/
├── QA_INDEX.md                    ← this file
├── README.md                      ← full project readme
├── replit.md                      ← workspace memory / architecture notes
├── .env.example                   ← all env vars documented
├── package.json                   ← workspace root (pnpm)
├── pnpm-workspace.yaml            ← workspace package globs
├── tsconfig.base.json             ← shared TS config
├── tsconfig.json                  ← root TS config
│
├── frontend/                      ← artifacts/cookcircle (React 18 + Vite + Tailwind 3)
│   ├── index.html
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   ├── package.json
│   ├── tsconfig.json
│   └── src/
│       ├── App.tsx                ← entire SPA (all screens, components, types)
│       ├── index.css              ← full design system (tokens, components, utilities)
│       ├── main.tsx               ← React entry point
│       └── lib/
│           └── api.ts             ← typed fetch client (the ONLY place that touches /api)
│
├── backend/                       ← artifacts/api-server (Express 5 + Drizzle)
│   ├── package.json
│   ├── tsconfig.json
│   ├── build.mjs                  ← esbuild CJS bundler
│   └── src/
│       ├── app.ts                 ← Express app setup (CORS, session, routes mount)
│       ├── index.ts               ← HTTP server entry
│       ├── routes/
│       │   ├── cookcircle.ts      ← all domain endpoints (donations, requests, reviews)
│       │   ├── cookcircle-seed.ts ← idempotent seed (runs on boot if users table empty)
│       │   ├── health.ts          ← GET /api/health → {status, db, media, location}
│       │   ├── index.ts           ← route aggregator
│       │   └── session.ts         ← simple CURRENT_USER_ID session stub
│       └── lib/
│           ├── media.ts           ← Cloudinary adapter (or local fallback)
│           ├── location.ts        ← Mapbox/Google geocoding adapter (or local fallback)
│           ├── session.ts         ← session helper
│           └── logger.ts          ← pino logger
│
├── db/                            ← lib/db (Drizzle ORM schema package)
│   ├── drizzle.config.ts
│   ├── package.json
│   ├── tsconfig.json
│   └── src/
│       ├── index.ts
│       └── schema/
│           ├── cookcircle.ts      ← Drizzle table definitions (users, donations, pickup_requests, reviews)
│           └── index.ts
│
├── api-spec/
│   └── openapi.yaml               ← OpenAPI 3.1 spec (source of truth for Orval codegen)
│
└── db/
    └── exports/
        ├── schema.sql             ← pg_dump --schema-only (DDL, enums, constraints, FKs)
        ├── sample_data.sql        ← pg_dump --data-only --column-inserts (5 users, 7 donations, 4 requests, 1 review)
        ├── users.csv
        ├── donations.csv          ← image_url column omitted (data URLs are large); image_public_id included
        ├── pickup_requests.csv
        └── reviews.csv
```

---

## 3. How to Run — Frontend

```bash
# From workspace root
pnpm install
pnpm --filter @workspace/cookcircle run dev
# Serves on PORT env var (default 5174 locally)
```

The frontend is a **single-page app** with no client-side router. Screen state is managed by `currentScreen` in App.tsx. There are no deep links.

---

## 4. How to Run — Backend

```bash
# Requires DATABASE_URL to be set (see .env.example)
pnpm --filter @workspace/api-server run dev
# Listens on PORT env var (default 8080 locally)
```

On first boot the seed runs automatically (`cookcircle-seed.ts`) when the `users` table is empty. It inserts 5 demo users and 7 donations.

Other useful commands:
```bash
pnpm run typecheck                              # typecheck all packages
pnpm --filter @workspace/db run push           # push schema changes to DB (dev only)
pnpm --filter @workspace/api-spec run codegen  # regenerate Orval hooks from openapi.yaml
```

---

## 5. Database Approach

- **Engine:** PostgreSQL (Replit-managed, connection via `DATABASE_URL`)
- **ORM:** Drizzle ORM — schema-first, fully typed
- **Schema location:** `db/src/schema/cookcircle.ts`
- **Migrations:** schema pushed directly with `drizzle-kit push` in dev; no migration files
- **4 tables:** `users`, `donations`, `pickup_requests`, `reviews`
- **Key constraints:**
  - `reviews_request_unique` index: one review per completed request
  - FK cascades on all child tables
  - `FOR UPDATE` row locking in the approve-request transaction (prevents double-approval)
  - Status guards at the route level (invalid transitions return `409 Conflict`)

---

## 6. Integration Status

| Adapter | Env vars needed | Current status in this workspace | Fallback behavior |
|---|---|---|---|
| **Media (image upload)** | `CLOUDINARY_CLOUD_NAME` + `CLOUDINARY_API_KEY` + `CLOUDINARY_API_SECRET` | **local (fallback)** | Deterministic food-themed gradient + emoji placeholder rendered client-side; user-uploaded images flow as data URLs |
| **Location (geocoding)** | `MAPBOX_TOKEN` or `GOOGLE_MAPS_API_KEY` | **local (fallback)** | Deterministic pseudo-coordinates derived from `address + city` hash; distance sort + OSM map iframe still fully functional |

Verify at runtime: `GET /api/health` → `{"status":"ok","db":"postgres","media":"local","location":"local"}`

To activate real providers: add the env vars from `.env.example` and restart the API server — no code changes required.

---

## 7. Known Remaining Gaps

| Gap | Severity | Notes |
|---|---|---|
| **No real auth** | By design | `CURRENT_USER_ID = 1` is hardcoded; a 5-user switcher chip in the header simulates switching. Auth was explicitly out of scope. |
| **No real Cloudinary** | Low | Works end-to-end with local fallback. Wire up `CLOUDINARY_*` env vars to activate. |
| **No real geocoding** | Low | Works end-to-end with deterministic coords. Wire up `MAPBOX_TOKEN` or `GOOGLE_MAPS_API_KEY` to activate. |
| **No URL routing** | Low | SPA uses internal screen state. Deep-linking to a specific donation is not supported. Out of scope. |
| **Broken-image fallback** | Very low | If an uploaded data URL is somehow malformed, the `<img>` shows a browser broken-image icon rather than falling back to the food emoji placeholder. |
| **No migration files** | Informational | Schema is pushed with `drizzle-kit push` (dev workflow). For production, Drizzle migration files would need to be generated. |

---

## 8. API Endpoints Reference

All routes are prefixed `/api`. See `openapi.yaml` for full spec.

| Method | Path | Description |
|---|---|---|
| GET | `/api/health` | Integration status |
| GET | `/api/users` | All users |
| GET | `/api/users/:id` | Single user |
| PUT | `/api/users/:id` | Update profile |
| GET | `/api/donations` | Feed (filterable by city, dietary tag, status, sort) |
| POST | `/api/donations` | Create donation |
| GET | `/api/donations/:id` | Single donation |
| PUT | `/api/donations/:id` | Update donation |
| DELETE | `/api/donations/:id` | Delete donation |
| PATCH | `/api/donations/:id/status` | Change donation status |
| GET | `/api/donations/:id/requests` | Requests for a donation |
| POST | `/api/requests` | Submit pickup request |
| GET | `/api/requests` | My requests |
| PATCH | `/api/requests/:id/approve` | Donor approves request |
| PATCH | `/api/requests/:id/decline` | Donor declines request |
| PATCH | `/api/requests/:id/status` | Update request status (complete/cancel) |
| POST | `/api/reviews` | Submit review |
| GET | `/api/reviews/:donationId` | Reviews for a donation |
| POST | `/api/media/upload` | Upload image (Cloudinary or local) |
| GET | `/api/geocode` | Geocode an address |
| GET | `/api/session` | Current session user |

---

*This bundle contains no real credentials, no production data, and no private keys.*
