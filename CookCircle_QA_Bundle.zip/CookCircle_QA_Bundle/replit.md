# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## CookCircle (artifacts/cookcircle + artifacts/api-server)

Food-donation MVP. Approved scope locked: donation lifecycle, pickup requests, reviews/ratings, dietary tags, privacy/discreet pickup, media + location integration, Postgres-backed backend. **Out of scope** (do not add): chat, AI, shared cooking, admin, payments, delivery logistics, advanced notifications, gamification.

Architecture:
- **DB schema**: `lib/db/src/schema/cookcircle.ts` — users, donations, pickup_requests, reviews; FK cascades; status enums; unique `(request_id, reviewer_id)` index.
- **API**: `artifacts/api-server/src/routes/cookcircle.ts` (Drizzle, transactions + `FOR UPDATE` locking, status guards, donor rating aggregation on review).
- **Seed**: `artifacts/api-server/src/routes/cookcircle-seed.ts` — idempotent (only runs when `users` is empty), backfills image URLs.
- **Media adapter**: `artifacts/api-server/src/lib/media.ts` — Cloudinary when `CLOUDINARY_*` set, else deterministic picsum. Always assigns an `imageUrl` on create.
- **Location adapter**: `artifacts/api-server/src/lib/location.ts` — Mapbox/Google when token set, else deterministic pseudo-coords from address+city.
- **Web client**: `artifacts/cookcircle/src/App.tsx` (single screen-router component) calls into `artifacts/cookcircle/src/lib/api.ts` (typed fetch client; the only place that touches `/api`).
- `GET /api/health` returns `{ status, db, media, location }`.
- Privacy: full address is gated client-side (own donation OR approved/completed request). `CURRENT_USER_ID = 1` is hardcoded — there is no auth.
