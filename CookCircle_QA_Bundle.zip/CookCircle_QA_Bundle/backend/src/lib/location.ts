// Location adapter for donations.
// Real provider: if MAPBOX_TOKEN (or GOOGLE_MAPS_API_KEY) is present we call a
// real geocoding endpoint. Otherwise we fall back to a deterministic
// pseudo-geocode keyed off the city name, which keeps the data shape stable
// for the UI and downstream features without blocking on an API key.

export interface GeocodeResult {
  latitude: number | null;
  longitude: number | null;
  provider: "mapbox" | "google" | "local";
}

const mapboxToken = process.env.MAPBOX_TOKEN ?? "";
const googleKey = process.env.GOOGLE_MAPS_API_KEY ?? "";

export const locationProvider: GeocodeResult["provider"] = mapboxToken
  ? "mapbox"
  : googleKey
    ? "google"
    : "local";

function pseudoGeocode(query: string): GeocodeResult {
  if (!query) return { latitude: null, longitude: null, provider: "local" };
  let h = 0;
  for (let i = 0; i < query.length; i++) {
    h = (h * 31 + query.charCodeAt(i)) | 0;
  }
  // Spread roughly around a city centre (San Francisco) within ~0.1 deg.
  const lat = 37.77 + ((h & 0xff) / 255 - 0.5) * 0.1;
  const lng = -122.42 + (((h >> 8) & 0xff) / 255 - 0.5) * 0.1;
  return {
    latitude: Number(lat.toFixed(6)),
    longitude: Number(lng.toFixed(6)),
    provider: "local",
  };
}

export async function geocodeAddress(
  address: string,
  city: string,
): Promise<GeocodeResult> {
  const query = [address, city].filter(Boolean).join(", ");
  if (mapboxToken) {
    try {
      const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(
        query,
      )}.json?limit=1&access_token=${mapboxToken}`;
      const res = await fetch(url);
      if (res.ok) {
        const j = (await res.json()) as { features: { center: [number, number] }[] };
        const c = j.features?.[0]?.center;
        if (c)
          return { longitude: c[0], latitude: c[1], provider: "mapbox" };
      }
    } catch (err) {
      console.warn("cookcircle location: mapbox failed, using fallback", err);
    }
  }
  if (googleKey) {
    try {
      const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(
        query,
      )}&key=${googleKey}`;
      const res = await fetch(url);
      if (res.ok) {
        const j = (await res.json()) as {
          results: { geometry: { location: { lat: number; lng: number } } }[];
        };
        const loc = j.results?.[0]?.geometry?.location;
        if (loc)
          return {
            latitude: loc.lat,
            longitude: loc.lng,
            provider: "google",
          };
      }
    } catch (err) {
      console.warn("cookcircle location: google failed, using fallback", err);
    }
  }
  return pseudoGeocode(query);
}

// Returns the public-safe location view for a donation, applying the
// "no full address before approval" privacy rule.
export interface PublicLocation {
  city: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
}

export function publicLocation(
  donation: {
    city: string;
    address: string;
    latitude: number | null;
    longitude: number | null;
    hideAddress: boolean | null;
  },
  reveal: boolean,
): PublicLocation {
  if (reveal || !donation.hideAddress) {
    return {
      city: donation.city,
      address: donation.address,
      latitude: donation.latitude,
      longitude: donation.longitude,
    };
  }
  return {
    city: donation.city,
    address: null,
    latitude: null,
    longitude: null,
  };
}
