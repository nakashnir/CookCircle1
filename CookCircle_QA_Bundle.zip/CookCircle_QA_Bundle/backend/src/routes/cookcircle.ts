import { Router, type IRouter, type Request, type Response } from "express";
import { and, desc, eq, sql } from "drizzle-orm";
import {
  db,
  donationsTable,
  pickupRequestsTable,
  reviewsTable,
  usersTable,
  type Donation,
  type PickupRequest,
  type Review,
  type User,
} from "@workspace/db";
import { geocodeAddress, locationProvider } from "../lib/location";
import { mediaProvider, uploadDonationImage } from "../lib/media";
import { getSessionUserId } from "../lib/session";
import { ensureSeed } from "./cookcircle-seed";

type DietaryTag = "kosher" | "gluten_free" | "vegan" | "vegetarian";
type DonationStatus = Donation["status"];
type RequestStatus = PickupRequest["status"];

const VALID_DIETARY: DietaryTag[] = [
  "kosher",
  "gluten_free",
  "vegan",
  "vegetarian",
];
const VALID_DONATION_STATUS: DonationStatus[] = [
  "available",
  "reserved",
  "picked_up",
  "cancelled",
  "expired",
];
const VALID_REQUEST_STATUS: RequestStatus[] = [
  "pending",
  "approved",
  "cancelled",
  "completed",
];

function bad(res: Response, status: number, message: string) {
  res.status(status).json({ error: message });
}

function sanitizeTags(input: unknown): DietaryTag[] {
  if (!Array.isArray(input)) return [];
  return input.filter((t): t is DietaryTag =>
    VALID_DIETARY.includes(t as DietaryTag),
  );
}

// Shape donations exactly as the frontend expects (camelCase, ISO strings).
// `reveal` controls whether the precise pickup details (address, lat, lng)
// are returned. The caller decides per-donation based on viewer identity.
function shapeDonation(d: Donation, reveal: boolean) {
  const exposeFull = reveal || !d.hideAddress;
  return {
    id: d.id,
    title: d.title,
    description: d.description,
    foodType: d.foodType,
    quantity: d.quantity,
    expiryDate: d.expiryDate,
    dietaryTags: d.dietaryTags ?? [],
    city: d.city,
    address: exposeFull ? d.address : null,
    latitude: exposeFull ? d.latitude : null,
    longitude: exposeFull ? d.longitude : null,
    imageUrl: d.imageUrl,
    imagePublicId: d.imagePublicId,
    donorId: d.donorId,
    status: d.status,
    createdAt: d.createdAt instanceof Date ? d.createdAt.toISOString() : d.createdAt,
    hideAddress: d.hideAddress,
    allowDiscreet: d.allowDiscreet,
    canSeeAddress: exposeFull,
  };
}

// Pickup-details access policy.
// A viewer can see the full pickup address/coordinates for a donation if
// either (a) they own the donation, or (b) they have an approved/completed
// pickup request for it. Used by GET /donations and GET /donations/:id.
async function donationsRevealableByViewer(
  viewerId: number,
): Promise<Set<number>> {
  const reveal = new Set<number>();
  const owned = await db
    .select({ id: donationsTable.id })
    .from(donationsTable)
    .where(eq(donationsTable.donorId, viewerId));
  for (const r of owned) reveal.add(r.id);
  const requested = await db
    .select({ id: pickupRequestsTable.donationId })
    .from(pickupRequestsTable)
    .where(
      and(
        eq(pickupRequestsTable.requesterId, viewerId),
        sql`${pickupRequestsTable.status} in ('approved','completed')`,
      ),
    );
  for (const r of requested) reveal.add(r.id);
  return reveal;
}

function shapeRequest(r: PickupRequest) {
  return {
    id: r.id,
    donationId: r.donationId,
    requesterId: r.requesterId,
    pickupTime: r.pickupTime,
    notes: r.notes,
    discreetPickup: r.discreetPickup,
    status: r.status,
    createdAt:
      r.createdAt instanceof Date ? r.createdAt.toISOString() : r.createdAt,
  };
}

function shapeReview(r: Review) {
  return {
    id: r.id,
    donationId: r.donationId,
    requestId: r.requestId,
    reviewerId: r.reviewerId,
    revieweeId: r.revieweeId,
    rating: r.rating,
    comment: r.comment,
    createdAt:
      r.createdAt instanceof Date ? r.createdAt.toISOString() : r.createdAt,
  };
}

function shapeUser(u: User) {
  return {
    id: u.id,
    displayName: u.displayName,
    email: u.email,
    phone: u.phone,
    dietaryPreferences: u.dietaryPreferences ?? [],
    discreetPickup: u.discreetPickup,
    rating: u.rating,
    reviewCount: u.reviewCount,
  };
}

const router: IRouter = Router();

// Lazy-seed on first request to avoid blocking startup if DB is slow.
let seeded = false;
router.use(async (_req, _res, next) => {
  if (!seeded) {
    try {
      await ensureSeed();
      seeded = true;
    } catch (err) {
      console.error("cookcircle: seed failed", err);
    }
  }
  next();
});

router.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    db: "postgres",
    media: mediaProvider,
    location: locationProvider,
  });
});

// ---------- Users ----------
router.get("/users", async (_req, res) => {
  const rows = await db.select().from(usersTable).orderBy(usersTable.id);
  res.json(rows.map(shapeUser));
});

// ---------- Donations ----------
function haversineKm(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): number {
  const R = 6371;
  const toRad = (x: number) => (x * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

router.get("/donations", async (req, res) => {
  const viewerId = getSessionUserId(req);
  const q = req.query;
  const filterCity = typeof q.city === "string" && q.city ? q.city : null;
  const filterDietary =
    typeof q.dietary === "string" && q.dietary
      ? q.dietary
          .split(",")
          .map((s) => s.trim())
          .filter((s): s is DietaryTag => VALID_DIETARY.includes(s as DietaryTag))
      : [];
  const statusParam = typeof q.status === "string" ? q.status : "available";
  const filterStatus =
    statusParam === "any"
      ? null
      : VALID_DONATION_STATUS.includes(statusParam as DonationStatus)
        ? (statusParam as DonationStatus)
        : "available";
  const sort =
    q.sort === "expiring" || q.sort === "nearest" || q.sort === "newest"
      ? (q.sort as "expiring" | "nearest" | "newest")
      : "newest";
  const lat = typeof q.lat === "string" ? Number(q.lat) : NaN;
  const lng = typeof q.lng === "string" ? Number(q.lng) : NaN;
  const radiusKm = typeof q.radiusKm === "string" ? Number(q.radiusKm) : NaN;
  const haveOrigin = Number.isFinite(lat) && Number.isFinite(lng);

  const conds = [];
  if (filterStatus) conds.push(eq(donationsTable.status, filterStatus));
  if (filterCity) conds.push(eq(donationsTable.city, filterCity));
  for (const tag of filterDietary) {
    conds.push(sql`${donationsTable.dietaryTags} @> ${JSON.stringify([tag])}::jsonb`);
  }

  const baseQuery = db.select().from(donationsTable);
  const rows = await (conds.length
    ? baseQuery.where(and(...conds))
    : baseQuery
  ).orderBy(desc(donationsTable.createdAt));

  let enriched = rows.map((d) => {
    const distanceKm =
      haveOrigin && d.latitude != null && d.longitude != null
        ? haversineKm({ lat, lng }, { lat: d.latitude, lng: d.longitude })
        : null;
    return { d, distanceKm };
  });

  if (haveOrigin && Number.isFinite(radiusKm) && radiusKm > 0) {
    enriched = enriched.filter(
      (r) => r.distanceKm != null && r.distanceKm <= radiusKm,
    );
  }

  if (sort === "nearest" && haveOrigin) {
    enriched.sort(
      (a, b) =>
        (a.distanceKm ?? Number.POSITIVE_INFINITY) -
        (b.distanceKm ?? Number.POSITIVE_INFINITY),
    );
  } else if (sort === "expiring") {
    enriched.sort(
      (a, b) =>
        new Date(a.d.expiryDate).getTime() - new Date(b.d.expiryDate).getTime(),
    );
  }

  const revealable = await donationsRevealableByViewer(viewerId);
  res.json(
    enriched.map(({ d, distanceKm }) => ({
      ...shapeDonation(d, revealable.has(d.id)),
      distanceKm: distanceKm == null ? null : Number(distanceKm.toFixed(2)),
    })),
  );
});

router.get("/donations/:id", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return bad(res, 400, "Invalid id");
  const viewerId = getSessionUserId(req);
  const [d] = await db
    .select()
    .from(donationsTable)
    .where(eq(donationsTable.id, id));
  if (!d) return bad(res, 404, "Donation not found");
  let reveal = d.donorId === viewerId;
  if (!reveal) {
    const r = await db
      .select({ id: pickupRequestsTable.id })
      .from(pickupRequestsTable)
      .where(
        and(
          eq(pickupRequestsTable.donationId, id),
          eq(pickupRequestsTable.requesterId, viewerId),
          sql`${pickupRequestsTable.status} in ('approved','completed')`,
        ),
      );
    reveal = r.length > 0;
  }
  res.json(shapeDonation(d, reveal));
});

router.post("/donations", async (req: Request, res: Response) => {
  const b = req.body ?? {};
  const required = [
    "title",
    "description",
    "foodType",
    "quantity",
    "expiryDate",
    "city",
    "address",
  ];
  for (const k of required) {
    if (typeof b[k] !== "string" || !b[k]) {
      return bad(res, 400, `Missing or invalid field: ${k}`);
    }
  }
  const donorId = getSessionUserId(req);
  const geo = await geocodeAddress(b.address, b.city);
  // Always run through the media adapter so every donation has a stable
  // image_url, even when no upload was provided. Real Cloudinary kicks in
  // automatically when credentials are configured.
  const m = await uploadDonationImage({
    data: b.image?.data ?? b.imageUrl,
    hint: `${b.title}-${Date.now()}`,
  });
  const imageUrl = m.imageUrl;
  const imagePublicId = m.imagePublicId;
  const [created] = await db
    .insert(donationsTable)
    .values({
      donorId,
      title: b.title,
      description: b.description,
      foodType: b.foodType,
      quantity: b.quantity,
      expiryDate: b.expiryDate,
      dietaryTags: sanitizeTags(b.dietaryTags),
      city: b.city,
      address: b.address,
      latitude: geo.latitude,
      longitude: geo.longitude,
      imageUrl,
      imagePublicId,
      status: "available",
      hideAddress: b.hideAddress !== undefined ? !!b.hideAddress : true,
      allowDiscreet: !!b.allowDiscreet,
    })
    .returning();
  res.status(201).json(shapeDonation(created, true));
});

// Donor-driven donation status transitions. The request flow controls
// `reserved` and `picked_up`; the donor can only move the donation between
// the listing-side states.
const DONOR_TRANSITIONS: Record<DonationStatus, DonationStatus[]> = {
  available: ["cancelled", "expired"],
  reserved: ["cancelled"],
  cancelled: ["available"],
  expired: ["available"],
  picked_up: [],
};

router.patch("/donations/:id", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return bad(res, 400, "Invalid id");
  const viewerId = getSessionUserId(req);
  try {
    const updated = await db.transaction(async (tx) => {
      const [existing] = await tx
        .select()
        .from(donationsTable)
        .where(eq(donationsTable.id, id))
        .for("update");
      if (!existing) throw Object.assign(new Error("Donation not found"), { http: 404 });
      if (existing.donorId !== viewerId)
        throw Object.assign(new Error("Only the donor can edit this donation"), { http: 403 });
      const b = req.body ?? {};
      const patch: Partial<Donation> = {};
      for (const k of [
        "title",
        "description",
        "foodType",
        "quantity",
        "expiryDate",
        "city",
        "address",
      ] as const) {
        if (typeof b[k] === "string") patch[k] = b[k];
      }
      if ("dietaryTags" in b) patch.dietaryTags = sanitizeTags(b.dietaryTags);
      if ("hideAddress" in b) patch.hideAddress = !!b.hideAddress;
      if ("allowDiscreet" in b) patch.allowDiscreet = !!b.allowDiscreet;
      if ("status" in b) {
        const next = b.status as DonationStatus;
        if (!VALID_DONATION_STATUS.includes(next))
          throw Object.assign(new Error("Invalid status"), { http: 400 });
        if (next !== existing.status) {
          const allowed = DONOR_TRANSITIONS[existing.status] ?? [];
          if (!allowed.includes(next)) {
            throw Object.assign(
              new Error(`Cannot transition donation from ${existing.status} to ${next}`),
              { http: 409 },
            );
          }
          patch.status = next;
          // When donor cancels a reserved donation, cancel any open requests too.
          if (existing.status === "reserved" && next === "cancelled") {
            await tx
              .update(pickupRequestsTable)
              .set({ status: "cancelled" })
              .where(
                and(
                  eq(pickupRequestsTable.donationId, id),
                  sql`${pickupRequestsTable.status} in ('pending','approved')`,
                ),
              );
          }
        }
      }
      if (patch.city || patch.address) {
        const geo = await geocodeAddress(
          patch.address ?? existing.address,
          patch.city ?? existing.city,
        );
        patch.latitude = geo.latitude;
        patch.longitude = geo.longitude;
      }
      if (b.image?.data) {
        const m = await uploadDonationImage({
          data: b.image.data,
          hint: patch.title ?? existing.title,
        });
        patch.imageUrl = m.imageUrl;
        patch.imagePublicId = m.imagePublicId;
      }
      if (Object.keys(patch).length === 0) return existing;
      const [u] = await tx
        .update(donationsTable)
        .set(patch)
        .where(eq(donationsTable.id, id))
        .returning();
      return u;
    });
    res.json(shapeDonation(updated, true));
  } catch (err: any) {
    if (err?.http) return res.status(err.http).json({ error: err.message });
    throw err;
  }
});

router.delete("/donations/:id", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return bad(res, 400, "Invalid id");
  const viewerId = getSessionUserId(req);
  const [existing] = await db
    .select({ donorId: donationsTable.donorId })
    .from(donationsTable)
    .where(eq(donationsTable.id, id));
  if (!existing) return bad(res, 404, "Donation not found");
  if (existing.donorId !== viewerId)
    return bad(res, 403, "Only the donor can delete this donation");
  await db.delete(donationsTable).where(eq(donationsTable.id, id));
  res.status(204).end();
});

// ---------- Requests ----------
router.get("/requests", async (req, res) => {
  const viewerId = getSessionUserId(req);
  const rows = await db
    .select({
      r: pickupRequestsTable,
      donorId: donationsTable.donorId,
    })
    .from(pickupRequestsTable)
    .innerJoin(donationsTable, eq(pickupRequestsTable.donationId, donationsTable.id))
    .orderBy(desc(pickupRequestsTable.createdAt));
  const visible = rows
    .filter((row) => row.r.requesterId === viewerId || row.donorId === viewerId)
    .map((row) => shapeRequest(row.r));
  res.json(visible);
});

router.post(
  "/donations/:id/requests",
  async (req: Request, res: Response) => {
    const donationId = Number(req.params.id);
    if (!Number.isFinite(donationId)) return bad(res, 400, "Invalid id");
    const b = req.body ?? {};
    if (typeof b.pickupTime !== "string" || !b.pickupTime) {
      return bad(res, 400, "Missing or invalid field: pickupTime");
    }
    const requesterId = getSessionUserId(req);

    const created = await db.transaction(async (tx) => {
      const [donation] = await tx
        .select()
        .from(donationsTable)
        .where(eq(donationsTable.id, donationId))
        .for("update");
      if (!donation) throw Object.assign(new Error("Donation not found"), { http: 404 });
      if (donation.status !== "available") {
        throw Object.assign(new Error("Donation is not available"), { http: 409 });
      }
      if (donation.donorId === requesterId) {
        throw Object.assign(new Error("Cannot request your own donation"), {
          http: 409,
        });
      }
      const [r] = await tx
        .insert(pickupRequestsTable)
        .values({
          donationId,
          requesterId,
          pickupTime: b.pickupTime,
          notes: typeof b.notes === "string" ? b.notes : "",
          discreetPickup: !!b.discreetPickup,
          status: "pending",
        })
        .returning();
      await tx
        .update(donationsTable)
        .set({ status: "reserved" })
        .where(eq(donationsTable.id, donationId));
      return r;
    }).catch((err: any) => {
      if (err?.http) return res.status(err.http).json({ error: err.message });
      throw err;
    });
    if (!created || res.headersSent) return;
    res.status(201).json(shapeRequest(created as PickupRequest));
  },
);

async function transitionRequest(
  requestId: number,
  newStatus: RequestStatus,
  actorId: number,
  res: Response,
) {
  try {
    const result = await db.transaction(async (tx) => {
      const [r] = await tx
        .select()
        .from(pickupRequestsTable)
        .where(eq(pickupRequestsTable.id, requestId))
        .for("update");
      if (!r) throw Object.assign(new Error("Request not found"), { http: 404 });

      const [donation] = await tx
        .select({ donorId: donationsTable.donorId })
        .from(donationsTable)
        .where(eq(donationsTable.id, r.donationId));
      const isDonor = donation?.donorId === actorId;
      const isRequester = r.requesterId === actorId;

      // Authorization: donor approves/declines; requester completes/cancels.
      if (newStatus === "approved" && !isDonor) {
        throw Object.assign(new Error("Only the donor can approve a request"), { http: 403 });
      }
      if (newStatus === "completed" && !isRequester) {
        throw Object.assign(new Error("Only the requester can mark pickup complete"), { http: 403 });
      }
      if (newStatus === "cancelled" && !isDonor && !isRequester) {
        throw Object.assign(new Error("Not allowed to cancel this request"), { http: 403 });
      }

      // Status transition guards.
      if (newStatus === "completed") {
        if (r.status !== "approved") {
          throw Object.assign(new Error("Only approved requests can be completed"), { http: 409 });
        }
      }
      if (newStatus === "approved") {
        if (r.status !== "pending") {
          throw Object.assign(new Error("Only pending requests can be approved"), { http: 409 });
        }
      }
      if (newStatus === "cancelled") {
        if (r.status === "completed")
          throw Object.assign(new Error("Cannot cancel a completed request"), { http: 409 });
      }

      const [updated] = await tx
        .update(pickupRequestsTable)
        .set({ status: newStatus })
        .where(eq(pickupRequestsTable.id, requestId))
        .returning();

      // Cascade donation status as required by the MVP rules.
      if (newStatus === "completed") {
        await tx
          .update(donationsTable)
          .set({ status: "picked_up" })
          .where(eq(donationsTable.id, r.donationId));
      } else if (newStatus === "cancelled") {
        const [donation] = await tx
          .select()
          .from(donationsTable)
          .where(eq(donationsTable.id, r.donationId));
        if (donation && donation.status === "reserved") {
          // Only free the donation if no other active requests remain.
          const others = await tx
            .select({ id: pickupRequestsTable.id })
            .from(pickupRequestsTable)
            .where(
              and(
                eq(pickupRequestsTable.donationId, r.donationId),
                sql`${pickupRequestsTable.status} in ('pending','approved')`,
              ),
            );
          if (others.length === 0) {
            await tx
              .update(donationsTable)
              .set({ status: "available" })
              .where(eq(donationsTable.id, r.donationId));
          }
        }
      }
      return updated;
    });
    res.json(shapeRequest(result));
  } catch (err: any) {
    if (err?.http) return res.status(err.http).json({ error: err.message });
    throw err;
  }
}

router.patch("/requests/:id", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return bad(res, 400, "Invalid id");
  const newStatus = req.body?.status as RequestStatus | undefined;
  if (!newStatus || !VALID_REQUEST_STATUS.includes(newStatus)) {
    return bad(res, 400, "Invalid or missing status");
  }
  await transitionRequest(id, newStatus, getSessionUserId(req), res);
});

router.post("/requests/:id/cancel", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return bad(res, 400, "Invalid id");
  await transitionRequest(id, "cancelled", getSessionUserId(req), res);
});

router.post("/requests/:id/complete", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return bad(res, 400, "Invalid id");
  await transitionRequest(id, "completed", getSessionUserId(req), res);
});

// ---------- Reviews ----------
router.get("/reviews", async (_req, res) => {
  const rows = await db
    .select()
    .from(reviewsTable)
    .orderBy(desc(reviewsTable.createdAt));
  res.json(rows.map(shapeReview));
});

router.post(
  "/requests/:id/reviews",
  async (req: Request, res: Response) => {
    const requestId = Number(req.params.id);
    if (!Number.isFinite(requestId)) return bad(res, 400, "Invalid id");
    const b = req.body ?? {};
    const rating = Number(b.rating);
    if (!rating || rating < 1 || rating > 5) {
      return bad(res, 400, "rating must be between 1 and 5");
    }
    const reviewerId = getSessionUserId(req);

    try {
      const result = await db.transaction(async (tx) => {
        const [r] = await tx
          .select()
          .from(pickupRequestsTable)
          .where(eq(pickupRequestsTable.id, requestId));
        if (!r) throw Object.assign(new Error("Request not found"), { http: 404 });
        if (r.status !== "completed") {
          throw Object.assign(
            new Error("Reviews allowed only on completed requests"),
            { http: 409 },
          );
        }
        if (r.requesterId !== reviewerId) {
          throw Object.assign(
            new Error("Only the requester can review this pickup"),
            { http: 403 },
          );
        }
        const [d] = await tx
          .select()
          .from(donationsTable)
          .where(eq(donationsTable.id, r.donationId));
        if (!d) throw Object.assign(new Error("Donation not found"), { http: 404 });

        const existing = await tx
          .select({ id: reviewsTable.id })
          .from(reviewsTable)
          .where(eq(reviewsTable.requestId, requestId));
        if (existing.length > 0) {
          throw Object.assign(
            new Error("Review already submitted for this request"),
            { http: 409 },
          );
        }
        const [review] = await tx
          .insert(reviewsTable)
          .values({
            donationId: d.id,
            requestId,
            reviewerId,
            revieweeId: d.donorId,
            rating,
            comment: typeof b.comment === "string" ? b.comment : "",
          })
          .returning();

        // Recompute donor's aggregate rating.
        const [{ avg, cnt }] = await tx
          .select({
            avg: sql<number>`coalesce(avg(${reviewsTable.rating})::float8, 0)`,
            cnt: sql<number>`count(*)::int`,
          })
          .from(reviewsTable)
          .where(eq(reviewsTable.revieweeId, d.donorId));
        await tx
          .update(usersTable)
          .set({ rating: avg, reviewCount: cnt })
          .where(eq(usersTable.id, d.donorId));
        return review;
      });
      res.status(201).json(shapeReview(result));
    } catch (err: any) {
      if (err?.http) return res.status(err.http).json({ error: err.message });
      throw err;
    }
  },
);

export default router;
