import { sql } from "drizzle-orm";
import {
  db,
  donationsTable,
  pickupRequestsTable,
  reviewsTable,
  usersTable,
} from "@workspace/db";

function seedImage(title: string) {
  const s = encodeURIComponent(title.slice(0, 60));
  return {
    imageUrl: `https://picsum.photos/seed/${s}/640/480`,
    imagePublicId: `local/${s}`,
  };
}

// Seed the database with the canonical demo data on first boot. Idempotent —
// only runs when the users table is empty so it never clobbers real data.
export async function ensureSeed(): Promise<void> {
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(usersTable);
  if (count > 0) return;

  await db.transaction(async (tx) => {
    await tx.insert(usersTable).values([
      {
        id: 1,
        displayName: "Alex Chen",
        email: "alex@example.com",
        phone: "555-0101",
        dietaryPreferences: ["vegetarian"],
        discreetPickup: false,
        rating: 4.8,
        reviewCount: 23,
      },
      {
        id: 2,
        displayName: "Maria Garcia",
        email: "maria@example.com",
        phone: "555-0102",
        dietaryPreferences: ["vegan"],
        discreetPickup: true,
        rating: 4.9,
        reviewCount: 47,
      },
      {
        id: 3,
        displayName: "John Smith",
        email: "john@example.com",
        phone: "555-0103",
        dietaryPreferences: [],
        discreetPickup: false,
        rating: 4.6,
        reviewCount: 18,
      },
      {
        id: 4,
        displayName: "Sarah Johnson",
        email: "sarah@example.com",
        phone: "555-0104",
        dietaryPreferences: ["gluten_free"],
        discreetPickup: false,
        rating: 5.0,
        reviewCount: 31,
      },
      {
        id: 5,
        displayName: "David Lee",
        email: "david@example.com",
        phone: "555-0105",
        dietaryPreferences: [],
        discreetPickup: false,
        rating: 4.7,
        reviewCount: 15,
      },
    ]);
    await tx.execute(
      sql`select setval(pg_get_serial_sequence('users', 'id'), 5, true)`,
    );

    await tx.insert(donationsTable).values([
      {
        id: 1,
        donorId: 2,
        title: "Fresh Vegetables",
        description:
          "Mixed fresh vegetables including tomatoes, cucumbers, lettuce, and carrots. All organic and locally grown.",
        foodType: "Produce",
        quantity: "5 kg",
        expiryDate: "2026-04-22T18:00",
        dietaryTags: ["vegan"],
        city: "Downtown",
        address: "123 Main Street",
        status: "reserved",
        hideAddress: true,
      },
      {
        id: 2,
        donorId: 3,
        title: "Homemade Pasta",
        description:
          "Fresh homemade pasta with tomato sauce. Made this morning, perfect for a quick meal.",
        foodType: "Prepared Food",
        quantity: "10 portions",
        expiryDate: "2026-04-20T20:00",
        dietaryTags: ["vegetarian"],
        city: "West End",
        address: "456 Oak Avenue",
        status: "available",
        allowDiscreet: true,
        hideAddress: true,
      },
      {
        id: 3,
        donorId: 4,
        title: "Bread & Pastries",
        description:
          "Assorted bread and pastries from my bakery. All baked fresh this morning.",
        foodType: "Baked Goods",
        quantity: "20 items",
        expiryDate: "2026-04-19T22:00",
        dietaryTags: ["vegetarian"],
        city: "City Center",
        address: "789 Bakery Lane",
        status: "picked_up",
        hideAddress: true,
      },
      {
        id: 4,
        donorId: 5,
        title: "Canned Goods",
        description:
          "Various canned vegetables and beans. Non-perishable, great for stocking up.",
        foodType: "Non-Perishable",
        quantity: "15 cans",
        expiryDate: "2027-04-18T23:59",
        dietaryTags: ["vegan", "gluten_free"],
        city: "East Side",
        address: "321 Elm Street",
        status: "available",
        hideAddress: true,
      },
      {
        id: 5,
        donorId: 2,
        title: "Fresh Fruit",
        description:
          "Apples, bananas, and oranges. Slightly overripe but perfect for smoothies or baking.",
        foodType: "Produce",
        quantity: "3 kg",
        expiryDate: "2026-04-21T18:00",
        dietaryTags: ["vegan"],
        city: "North District",
        address: "555 Apple Road",
        status: "available",
        hideAddress: true,
      },
      {
        id: 6,
        donorId: 1,
        title: "Garden Herbs",
        description:
          "Fresh basil, mint, parsley, and rosemary from my home garden. Pick what you need.",
        foodType: "Produce",
        quantity: "Several bunches",
        expiryDate: "2026-04-25T18:00",
        dietaryTags: ["vegan", "gluten_free"],
        city: "Downtown",
        address: "12 Garden Lane",
        status: "reserved",
        hideAddress: true,
        allowDiscreet: true,
      },
      {
        id: 7,
        donorId: 1,
        title: "Lentil Soup (Family Batch)",
        description:
          "Big pot of lentil soup with carrots and celery. Already cooled, easy to reheat.",
        foodType: "Prepared Food",
        quantity: "8 portions",
        expiryDate: "2026-04-23T20:00",
        dietaryTags: ["vegan", "vegetarian"],
        city: "Downtown",
        address: "12 Garden Lane",
        status: "available",
        hideAddress: true,
      },
    ]);
    await tx.execute(
      sql`select setval(pg_get_serial_sequence('donations', 'id'), 7, true)`,
    );
    // Backfill stable placeholder image URLs through the same convention the
    // local media adapter uses, so the data shape always has image fields.
    await tx.execute(sql`
      update donations
      set
        image_url = 'https://picsum.photos/seed/' || replace(replace(left(title,60),' ','%20'),'&','%26') || '/640/480',
        image_public_id = 'local/' || replace(left(title,60),' ','%20')
      where image_url is null
    `);

    await tx.insert(pickupRequestsTable).values([
      {
        id: 1,
        donationId: 1,
        requesterId: 1,
        pickupTime: "2026-04-19T14:00",
        notes: "Please ring doorbell",
        discreetPickup: false,
        status: "approved",
      },
      {
        id: 2,
        donationId: 2,
        requesterId: 1,
        pickupTime: "2026-04-20T16:30",
        notes: "",
        discreetPickup: false,
        status: "pending",
      },
      {
        id: 3,
        donationId: 3,
        requesterId: 1,
        pickupTime: "2026-04-18T10:00",
        notes: "Back entrance pickup",
        discreetPickup: true,
        status: "completed",
      },
      {
        id: 4,
        donationId: 6,
        requesterId: 3,
        pickupTime: "2026-04-22T17:00",
        notes: "Would love to grab the basil if possible!",
        discreetPickup: false,
        status: "pending",
      },
    ]);
    await tx.execute(
      sql`select setval(pg_get_serial_sequence('pickup_requests', 'id'), 4, true)`,
    );

    await tx.insert(reviewsTable).values([
      {
        id: 1,
        donationId: 3,
        requestId: 3,
        reviewerId: 1,
        revieweeId: 4,
        rating: 5,
        comment: "Great quality pastries! Sarah was very kind and helpful.",
      },
    ]);
    await tx.execute(
      sql`select setval(pg_get_serial_sequence('reviews', 'id'), 1, true)`,
    );
  });
}
