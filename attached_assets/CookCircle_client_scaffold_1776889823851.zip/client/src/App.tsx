import { useState } from 'react';

type DietaryTag = 'kosher' | 'gluten_free' | 'vegan' | 'vegetarian';
type DonationStatus = 'available' | 'reserved' | 'picked_up' | 'cancelled' | 'expired';
type RequestStatus = 'pending' | 'approved' | 'cancelled' | 'completed';

interface User {
  id: number;
  displayName: string;
  email: string;
  phone: string;
  dietaryPreferences: DietaryTag[];
  discreetPickup: boolean;
  rating: number;
  reviewCount: number;
}

interface Donation {
  id: number;
  title: string;
  description: string;
  foodType: string;
  quantity: string;
  expiryDate: string;
  dietaryTags: DietaryTag[];
  city: string;
  address: string;
  donorId: number;
  status: DonationStatus;
  createdAt: string;
  hideAddress?: boolean;
  allowDiscreet?: boolean;
}

interface PickupRequest {
  id: number;
  donationId: number;
  requesterId: number;
  pickupTime: string;
  notes: string;
  discreetPickup: boolean;
  status: RequestStatus;
  createdAt: string;
}

interface Review {
  id: number;
  donationId: number;
  requestId: number;
  reviewerId: number;
  revieweeId: number;
  rating: number;
  comment: string;
  createdAt: string;
}

const CURRENT_USER_ID = 1;

const mockUsers: User[] = [
  { id: 1, displayName: 'Alex Chen', email: 'alex@example.com', phone: '555-0101', dietaryPreferences: ['vegan'], discreetPickup: false, rating: 4.8, reviewCount: 12 },
  { id: 2, displayName: 'John Smith', email: 'john@example.com', phone: '555-0102', dietaryPreferences: [], discreetPickup: false, rating: 4.8, reviewCount: 24 },
  { id: 3, displayName: 'Maria Garcia', email: 'maria@example.com', phone: '555-0103', dietaryPreferences: ['vegetarian'], discreetPickup: true, rating: 4.9, reviewCount: 18 },
  { id: 4, displayName: 'Sarah Johnson', email: 'sarah@example.com', phone: '555-0104', dietaryPreferences: ['gluten_free'], discreetPickup: false, rating: 5.0, reviewCount: 31 },
  { id: 5, displayName: 'David Lee', email: 'david@example.com', phone: '555-0105', dietaryPreferences: [], discreetPickup: false, rating: 4.7, reviewCount: 15 },
];

const initialDonations: Donation[] = [
  { id: 1, title: 'Fresh Vegetables', description: 'Mixed fresh vegetables including tomatoes, cucumbers, lettuce, and carrots. All organic and locally grown.', foodType: 'Produce', quantity: '5 kg', expiryDate: '2026-04-22T18:00', dietaryTags: ['vegan'], city: 'Downtown', address: '123 Main Street', donorId: 2, status: 'available', createdAt: '2026-04-18T10:00', hideAddress: true },
  { id: 2, title: 'Homemade Pasta', description: 'Fresh homemade pasta with tomato sauce. Made this morning, perfect for a quick meal.', foodType: 'Prepared Food', quantity: '10 portions', expiryDate: '2026-04-20T20:00', dietaryTags: ['vegetarian'], city: 'West End', address: '456 Oak Avenue', donorId: 3, status: 'available', createdAt: '2026-04-18T09:00', allowDiscreet: true },
  { id: 3, title: 'Bread & Pastries', description: 'Assorted bread and pastries from my bakery. All baked fresh this morning.', foodType: 'Baked Goods', quantity: '20 items', expiryDate: '2026-04-19T22:00', dietaryTags: ['vegetarian'], city: 'City Center', address: '789 Bakery Lane', donorId: 4, status: 'reserved', createdAt: '2026-04-18T08:00' },
  { id: 4, title: 'Canned Goods', description: 'Various canned vegetables and beans. Non-perishable, great for stocking up.', foodType: 'Non-Perishable', quantity: '15 cans', expiryDate: '2027-04-18T23:59', dietaryTags: ['vegan', 'gluten_free'], city: 'East Side', address: '321 Elm Street', donorId: 5, status: 'available', createdAt: '2026-04-17T15:00' },
  { id: 5, title: 'Fresh Fruit', description: 'Apples, bananas, and oranges. Slightly overripe but perfect for smoothies or baking.', foodType: 'Produce', quantity: '3 kg', expiryDate: '2026-04-21T18:00', dietaryTags: ['vegan'], city: 'North District', address: '555 Apple Road', donorId: 2, status: 'available', createdAt: '2026-04-17T12:00' },
];

const initialRequests: PickupRequest[] = [
  { id: 1, donationId: 1, requesterId: 1, pickupTime: '2026-04-19T14:00', notes: 'Please ring doorbell', discreetPickup: false, status: 'approved', createdAt: '2026-04-18T11:00' },
  { id: 2, donationId: 2, requesterId: 1, pickupTime: '2026-04-20T16:30', notes: '', discreetPickup: false, status: 'pending', createdAt: '2026-04-18T10:30' },
  { id: 3, donationId: 3, requesterId: 1, pickupTime: '2026-04-18T10:00', notes: 'Back entrance pickup', discreetPickup: true, status: 'completed', createdAt: '2026-04-17T20:00' },
];

const initialReviews: Review[] = [
  { id: 1, donationId: 3, requestId: 3, reviewerId: 1, revieweeId: 4, rating: 5, comment: 'Great quality pastries! Sarah was very kind and helpful.', createdAt: '2026-04-18T11:00' },
];

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'feed' | 'details' | 'create' | 'my-donations' | 'requests' | 'review' | 'profile'>('feed');
  const [selectedDonationId, setSelectedDonationId] = useState<number | null>(null);
  const [selectedRequestId, setSelectedRequestId] = useState<number | null>(null);
  const [donations, setDonations] = useState<Donation[]>(initialDonations);
  const [requests, setRequests] = useState<PickupRequest[]>(initialRequests);
  const [reviews, setReviews] = useState<Review[]>(initialReviews);
  const [users] = useState<User[]>(mockUsers);

  const currentUser = users.find(u => u.id === CURRENT_USER_ID)!;

  const viewDonationDetails = (donationId: number) => {
    setSelectedDonationId(donationId);
    setCurrentScreen('details');
  };

  const createPickupRequest = (donationId: number, pickupTime: string, notes: string, discreetPickup: boolean) => {
    const newRequest: PickupRequest = {
      id: requests.length + 1,
      donationId,
      requesterId: CURRENT_USER_ID,
      pickupTime,
      notes,
      discreetPickup,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    setRequests([...requests, newRequest]);
    setDonations(donations.map(d =>
      d.id === donationId ? { ...d, status: 'reserved' as DonationStatus } : d
    ));
    setCurrentScreen('requests');
  };

  const createDonation = (donation: Omit<Donation, 'id' | 'donorId' | 'status' | 'createdAt'>) => {
    const newDonation: Donation = {
      ...donation,
      id: donations.length + 1,
      donorId: CURRENT_USER_ID,
      status: 'available',
      createdAt: new Date().toISOString(),
    };
    setDonations([newDonation, ...donations]);
    setCurrentScreen('my-donations');
  };

  const updateRequestStatus = (requestId: number, newStatus: RequestStatus) => {
    setRequests(requests.map(r =>
      r.id === requestId ? { ...r, status: newStatus } : r
    ));
    if (newStatus === 'completed') {
      const request = requests.find(r => r.id === requestId);
      if (request) {
        setDonations(donations.map(d =>
          d.id === request.donationId ? { ...d, status: 'picked_up' as DonationStatus } : d
        ));
      }
    }
  };

  const openReviewScreen = (requestId: number) => {
    setSelectedRequestId(requestId);
    setCurrentScreen('review');
  };

  const submitReview = (requestId: number, rating: number, comment: string) => {
    const request = requests.find(r => r.id === requestId);
    if (!request) return;
    const donation = donations.find(d => d.id === request.donationId);
    if (!donation) return;
    const newReview: Review = {
      id: reviews.length + 1,
      donationId: request.donationId,
      requestId,
      reviewerId: CURRENT_USER_ID,
      revieweeId: donation.donorId,
      rating,
      comment,
      createdAt: new Date().toISOString(),
    };
    setReviews([...reviews, newReview]);
    setCurrentScreen('requests');
  };

  const deleteDonation = (donationId: number) => {
    setDonations(donations.filter(d => d.id !== donationId));
  };

  return (
    <div className="min-h-screen app-background">
      <Header currentScreen={currentScreen} onNavigate={setCurrentScreen} />
      <main className="max-w-7xl mx-auto px-8 py-8">
        {currentScreen === 'feed' && <DonationFeed donations={donations} users={users} onViewDetails={viewDonationDetails} />}
        {currentScreen === 'details' && selectedDonationId && (
          <DonationDetails
            donation={donations.find(d => d.id === selectedDonationId)!}
            donor={users.find(u => u.id === donations.find(d => d.id === selectedDonationId)?.donorId)!}
            onBack={() => setCurrentScreen('feed')}
            onSubmitRequest={createPickupRequest}
            currentUserId={CURRENT_USER_ID}
            requests={requests}
          />
        )}
        {currentScreen === 'create' && <CreateDonation onBack={() => setCurrentScreen('feed')} onSubmit={createDonation} />}
        {currentScreen === 'my-donations' && (
          <MyDonations
            donations={donations.filter(d => d.donorId === CURRENT_USER_ID)}
            requests={requests}
            users={users}
            onViewDetails={viewDonationDetails}
            onDelete={deleteDonation}
          />
        )}
        {currentScreen === 'requests' && (
          <MyRequests
            requests={requests.filter(r => r.requesterId === CURRENT_USER_ID)}
            donations={donations}
            users={users}
            onViewDonation={viewDonationDetails}
            onUpdateStatus={updateRequestStatus}
            onLeaveReview={openReviewScreen}
            reviews={reviews}
          />
        )}
        {currentScreen === 'review' && selectedRequestId && (
          <ReviewRating
            request={requests.find(r => r.id === selectedRequestId)!}
            donation={donations.find(d => d.id === requests.find(r => r.id === selectedRequestId)?.donationId)!}
            donor={users.find(u => u.id === donations.find(d => d.id === requests.find(r => r.id === selectedRequestId)?.donationId)?.donorId)!}
            onBack={() => setCurrentScreen('requests')}
            onSubmit={(rating, comment) => submitReview(selectedRequestId, rating, comment)}
          />
        )}
        {currentScreen === 'profile' && <Profile user={currentUser} onBack={() => setCurrentScreen('feed')} />}
      </main>
    </div>
  );
}

function Header({ currentScreen, onNavigate }: { currentScreen: string; onNavigate: (screen: any) => void; }) {
  return (
    <header className="header-gradient">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-8 py-5">
        <button onClick={() => onNavigate('feed')} className="text-2xl font-bold tracking-tight flex items-center gap-2 text-white">
          🥗 CookCircle
        </button>
        <nav className="flex gap-2">
          {[['feed', 'Home'], ['my-donations', 'My Donations'], ['requests', 'My Requests'], ['profile', 'Profile']].map(([screen, label]) => (
            <button
              key={screen}
              onClick={() => onNavigate(screen)}
              className={`px-5 py-2 text-sm font-medium rounded-lg transition-all ${
                currentScreen === screen ? 'nav-active' : 'nav-inactive'
              }`}
            >
              {label}
            </button>
          ))}
        </nav>
        <button onClick={() => onNavigate('create')} className="cta-button">
          + Create Donation
        </button>
      </div>
    </header>
  );
}

function StatusBadge({ status }: { status: DonationStatus | RequestStatus }) {
  const getClass = () => {
    switch (status) {
      case 'available': return 'status-available';
      case 'reserved': return 'status-reserved';
      case 'picked_up':
      case 'completed': return 'status-completed';
      case 'approved': return 'status-approved';
      case 'pending': return 'status-pending';
      case 'cancelled': return 'status-cancelled';
      case 'expired': return 'status-expired';
      default: return 'status-cancelled';
    }
  };
  const label = status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  return (
    <span className={`status-badge ${getClass()}`}>
      <span className="status-dot"></span>
      {label}
    </span>
  );
}

function DietaryTagBadge({ tag }: { tag: DietaryTag }) {
  const labels: Record<DietaryTag, string> = {
    kosher: 'Kosher', gluten_free: 'Gluten-Free', vegan: 'Vegan', vegetarian: 'Vegetarian',
  };
  return <span className="dietary-tag">{labels[tag]}</span>;
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="empty-state">
      <div className="max-w-md mx-auto">
        <div className="empty-icon">📦</div>
        <p className="empty-text">{message}</p>
      </div>
    </div>
  );
}

function DonationCard({ donation, donor, onViewDetails }: { donation: Donation; donor: User; onViewDetails: (id: number) => void; }) {
  return (
    <div className="card">
      <div className="card-image">
        <span className="text-6xl">🥗</span>
      </div>
      <div className="p-5">
        <h3 className="card-title">{donation.title}</h3>
        <div className="card-meta">
          <span className="flex items-center gap-1">👤 {donor.displayName}</span>
          <span className="card-rating">⭐ <span className="font-semibold">{donor.rating.toFixed(1)}</span></span>
        </div>
        <div className="space-y-2 mb-4">
          <div className="card-info"><span className="card-label">Type:</span><span className="card-value">{donation.foodType}</span></div>
          <div className="card-info"><span className="card-label">Quantity:</span><span className="card-value">{donation.quantity}</span></div>
          {donation.dietaryTags.length > 0 && (
            <div className="flex gap-1.5 flex-wrap pt-1">
              {donation.dietaryTags.map((tag) => <DietaryTagBadge key={tag} tag={tag} />)}
            </div>
          )}
          <div className="card-location"><span>📍</span> <span>{donation.city}</span></div>
        </div>
        <button onClick={() => onViewDetails(donation.id)} className="btn-primary w-full">
          View Details
        </button>
      </div>
    </div>
  );
}

function DonationFeed({ donations, users, onViewDetails }: { donations: Donation[]; users: User[]; onViewDetails: (id: number) => void; }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [cityFilter, setCityFilter] = useState('');
  const [dietaryFilter, setDietaryFilter] = useState<DietaryTag | ''>('');

  const filteredDonations = donations.filter((d) => {
    if (d.status !== 'available') return false;
    if (searchQuery && !d.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    if (cityFilter && d.city !== cityFilter) return false;
    if (dietaryFilter && !d.dietaryTags.includes(dietaryFilter)) return false;
    return true;
  });

  const cities = Array.from(new Set(donations.map(d => d.city)));

  return (
    <div>
      <div className="mb-8">
        <h1 className="page-title">Available Food Donations</h1>
        <p className="page-subtitle">Find fresh food shared by your neighbors</p>
      </div>
      <div className="filter-card">
        <div className="mb-4">
          <input type="text" placeholder="Search donations..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="input-field" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <select value={cityFilter} onChange={(e) => setCityFilter(e.target.value)} className="input-field">
            <option value="">All Cities</option>
            {cities.map(city => <option key={city} value={city}>{city}</option>)}
          </select>
          <select value={dietaryFilter} onChange={(e) => setDietaryFilter(e.target.value as DietaryTag | '')} className="input-field">
            <option value="">All Dietary Tags</option>
            <option value="vegan">Vegan</option>
            <option value="vegetarian">Vegetarian</option>
            <option value="gluten_free">Gluten-Free</option>
            <option value="kosher">Kosher</option>
          </select>
        </div>
      </div>
      {filteredDonations.length === 0 ? (
        <EmptyState message="No donations found matching your filters" />
      ) : (
        <div className="grid grid-cols-3 gap-6">
          {filteredDonations.map((d) => (
            <DonationCard key={d.id} donation={d} donor={users.find(u => u.id === d.donorId)!} onViewDetails={onViewDetails} />
          ))}
        </div>
      )}
    </div>
  );
}

function DonationDetails({ donation, donor, onBack, onSubmitRequest, currentUserId, requests }: {
  donation: Donation; donor: User; onBack: () => void; onSubmitRequest: any; currentUserId: number; requests: PickupRequest[];
}) {
  const [pickupTime, setPickupTime] = useState('');
  const [notes, setNotes] = useState('');
  const [discreetPickup, setDiscreetPickup] = useState(false);

  const handleSubmit = () => {
    if (!pickupTime) { alert('Please select a pickup time'); return; }
    onSubmitRequest(donation.id, pickupTime, notes, discreetPickup);
  };

  const formatDateTime = (iso: string) => new Date(iso).toLocaleString('en-US', { month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true });
  const isOwnDonation = donation.donorId === currentUserId;
  const userRequest = requests.find(r => r.donationId === donation.id && r.requesterId === currentUserId);
  const canSeeAddress = userRequest && (userRequest.status === 'approved' || userRequest.status === 'completed');

  return (
    <div>
      <div className="breadcrumb">
        <button onClick={onBack} className="breadcrumb-link">Home</button>
        <span>/</span>
        <span className="breadcrumb-current">Donation Details</span>
      </div>
      <div className="grid grid-cols-2 gap-8">
        <div>
          <div className="card-image-large mb-6"><span className="text-8xl">🥗</span></div>
          <div className="card">
            <div className="flex items-start justify-between mb-4">
              <h1 className="details-title">{donation.title}</h1>
              <StatusBadge status={donation.status} />
            </div>
            <div className="space-y-4 mb-6">
              <div><div className="detail-label">Description</div><div className="detail-value">{donation.description}</div></div>
              <div className="grid grid-cols-2 gap-4">
                <div><div className="detail-label">Food Type</div><div className="detail-value">{donation.foodType}</div></div>
                <div><div className="detail-label">Quantity</div><div className="detail-value">{donation.quantity}</div></div>
              </div>
              <div><div className="detail-label">Expiry Date</div><div className="detail-value">{formatDateTime(donation.expiryDate)}</div></div>
              {donation.dietaryTags.length > 0 && (
                <div><div className="detail-label">Dietary Tags</div><div className="flex gap-2 flex-wrap">{donation.dietaryTags.map(tag => <DietaryTagBadge key={tag} tag={tag} />)}</div></div>
              )}
              <div>
                <div className="detail-label">Pickup Location</div>
                <div className="flex items-start gap-2">
                  <span className="text-lg">📍</span>
                  <div>
                    <div className="detail-value">{canSeeAddress ? `${donation.address}, ${donation.city}` : donation.city}</div>
                    {!canSeeAddress && <div className="detail-privacy">Full address shared after request approval</div>}
                  </div>
                </div>
              </div>
            </div>
            <div className="donor-section">
              <div className="detail-label mb-3">Donor</div>
              <div className="flex items-center gap-4">
                <div className="donor-avatar">👤</div>
                <div className="flex-1">
                  <div className="donor-name">{donor.displayName}</div>
                  <div className="flex items-center gap-1 text-sm">
                    {[...Array(5)].map((_, i) => <span key={i} className={i < Math.floor(donor.rating) ? 'star-filled' : 'star-empty'}>⭐</span>)}
                    <span className="rating-value ml-1">{donor.rating.toFixed(1)}</span>
                    <span className="rating-count">({donor.reviewCount} reviews)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
          {isOwnDonation ? (
            <div className="card text-center"><span className="empty-text">This is your donation. You cannot request pickup for your own donation.</span></div>
          ) : donation.status !== 'available' ? (
            <div className="card text-center"><span className="empty-text">This donation is not available for pickup requests.</span></div>
          ) : (
            <div className="card">
              <h2 className="section-title mb-6">Request Pickup</h2>
              <div className="space-y-5">
                <div>
                  <label className="form-label">Preferred Pickup Time <span className="text-red-600">*</span></label>
                  <input type="datetime-local" value={pickupTime} onChange={(e) => setPickupTime(e.target.value)} className="input-field" />
                </div>
                <div>
                  <label className="form-label">Notes</label>
                  <textarea rows={4} placeholder="Add any special requests or notes for the donor..." value={notes} onChange={(e) => setNotes(e.target.value)} className="input-field resize-none" />
                </div>
                <div className="privacy-option">
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input type="checkbox" checked={discreetPickup} onChange={(e) => setDiscreetPickup(e.target.checked)} className="mt-1 w-4 h-4" />
                    <div>
                      <div className="privacy-label">Request discreet pickup</div>
                      <div className="privacy-desc">Donor will provide pickup instructions privately after approval</div>
                    </div>
                  </label>
                </div>
                <button onClick={handleSubmit} className="btn-primary w-full">Send Pickup Request</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function CreateDonation({ onBack, onSubmit }: { onBack: () => void; onSubmit: any }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [foodType, setFoodType] = useState('');
  const [quantity, setQuantity] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [dietaryTags, setDietaryTags] = useState<DietaryTag[]>([]);
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [hideAddress, setHideAddress] = useState(true);
  const [allowDiscreet, setAllowDiscreet] = useState(false);

  const handleSubmit = () => {
    if (!title || !description || !foodType || !quantity || !expiryDate || !city || !address) {
      alert('Please fill in all required fields');
      return;
    }
    onSubmit({ title, description, foodType, quantity, expiryDate, dietaryTags, city, address, hideAddress, allowDiscreet });
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="page-title">Create New Donation</h1>
        <p className="page-subtitle">Share your surplus food with the community</p>
      </div>
      <div className="grid grid-cols-2 gap-8">
        <div className="card space-y-5">
          <div><label className="form-label">Donation Title <span className="text-red-600">*</span></label><input type="text" placeholder="e.g., Fresh Vegetables" value={title} onChange={(e) => setTitle(e.target.value)} className="input-field" /></div>
          <div><label className="form-label">Description <span className="text-red-600">*</span></label><textarea rows={4} placeholder="Describe the food items..." value={description} onChange={(e) => setDescription(e.target.value)} className="input-field resize-none" /></div>
          <div>
            <label className="form-label">Food Type <span className="text-red-600">*</span></label>
            <select value={foodType} onChange={(e) => setFoodType(e.target.value)} className="input-field">
              <option value="">Select food type</option>
              {['Produce', 'Prepared Food', 'Baked Goods', 'Non-Perishable', 'Dairy', 'Meat & Seafood'].map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="form-label">Quantity <span className="text-red-600">*</span></label><input type="text" placeholder="e.g., 5 kg" value={quantity} onChange={(e) => setQuantity(e.target.value)} className="input-field" /></div>
            <div><label className="form-label">Expiry Date <span className="text-red-600">*</span></label><input type="datetime-local" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} className="input-field" /></div>
          </div>
          <div>
            <label className="form-label mb-3">Dietary Tags</label>
            <div className="grid grid-cols-2 gap-3">
              {(['vegan', 'vegetarian', 'gluten_free', 'kosher'] as DietaryTag[]).map((tag) => (
                <label key={tag} className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={dietaryTags.includes(tag)} onChange={() => setDietaryTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag])} className="w-4 h-4" />
                  <span className="form-checkbox-label">{tag === 'gluten_free' ? 'Gluten-Free' : tag.charAt(0).toUpperCase() + tag.slice(1)}</span>
                </label>
              ))}
            </div>
          </div>
          <div><label className="form-label">Pickup City <span className="text-red-600">*</span></label><input type="text" placeholder="Enter city" value={city} onChange={(e) => setCity(e.target.value)} className="input-field" /></div>
          <div><label className="form-label">Pickup Address <span className="text-red-600">*</span></label><input type="text" placeholder="Street address" value={address} onChange={(e) => setAddress(e.target.value)} className="input-field" /></div>
        </div>
        <div className="space-y-6">
          <div className="card">
            <label className="form-label mb-3">Upload Images</label>
            <div className="upload-area"><span className="text-6xl mb-3">📷</span><div className="upload-text">Click to upload or drag and drop</div><div className="upload-hint">PNG, JPG up to 10MB</div></div>
          </div>
          <div className="card">
            <label className="form-label mb-4">Privacy Options</label>
            <div className="space-y-3">
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={hideAddress} onChange={(e) => setHideAddress(e.target.checked)} className="mt-1 w-4 h-4" />
                <div><div className="privacy-label">Hide exact address until request approved</div><div className="privacy-desc">Only city and area shown publicly</div></div>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={allowDiscreet} onChange={(e) => setAllowDiscreet(e.target.checked)} className="mt-1 w-4 h-4" />
                <div><div className="privacy-label">Allow discreet pickup requests</div><div className="privacy-desc">Recipients can request private pickup instructions</div></div>
              </label>
            </div>
          </div>
          <div className="flex gap-4">
            <button onClick={onBack} className="btn-secondary flex-1">Cancel</button>
            <button onClick={handleSubmit} className="btn-primary flex-1">Publish Donation</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function MyDonations({ donations, requests, users, onViewDetails, onDelete }: any) {
  const formatDateTime = (iso: string) => new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  const getDonationRequests = (did: number) => requests.filter((r: any) => r.donationId === did);

  return (
    <div>
      <div className="mb-8"><h1 className="page-title">My Donations</h1><p className="page-subtitle">Manage your food donations and incoming requests</p></div>
      {donations.length === 0 ? <EmptyState message="You haven't created any donations yet" /> : (
        <div className="space-y-4">
          {donations.map((d: any) => {
            const dreqs = getDonationRequests(d.id);
            const pendingCount = dreqs.filter((r: any) => r.status === 'pending').length;
            return (
              <div key={d.id} className="card">
                <div className="grid grid-cols-12 gap-6">
                  <div className="col-span-8">
                    <div className="flex items-start justify-between mb-4">
                      <div><h3 className="card-title mb-1">{d.title}</h3><div className="card-meta">{d.foodType} • {d.quantity}</div></div>
                      <StatusBadge status={d.status} />
                    </div>
                    <div className="grid grid-cols-2 gap-4 mb-3">
                      <div className="card-info"><span className="card-label">Location: </span><span className="card-value">{d.city}</span></div>
                      <div className="card-info"><span className="card-label">Expires: </span><span className="card-value">{formatDateTime(d.expiryDate)}</span></div>
                    </div>
                    {pendingCount > 0 && <div className="alert-pending">⚠️ {pendingCount} pending request{pendingCount > 1 ? 's' : ''}</div>}
                  </div>
                  <div className="col-span-4 flex flex-col gap-2">
                    <button onClick={() => onViewDetails(d.id)} className="btn-primary">View Details</button>
                    <button onClick={() => confirm('Are you sure you want to delete this donation?') && onDelete(d.id)} className="btn-danger">Delete</button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function MyRequests({ requests, donations, users, onViewDonation, onUpdateStatus, onLeaveReview, reviews }: any) {
  const [activeTab, setActiveTab] = useState<'all' | RequestStatus>('all');
  const formatDateTime = (iso: string) => new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  const filteredRequests = activeTab === 'all' ? requests : requests.filter((r: any) => r.status === activeTab);
  const hasReview = (rid: number) => reviews.some((r: any) => r.requestId === rid);

  return (
    <div>
      <div className="mb-8"><h1 className="page-title">My Requests</h1><p className="page-subtitle">Track your pickup requests and their status</p></div>
      <div className="tab-bar">
        {(['all', 'pending', 'approved', 'completed', 'cancelled'] as const).map((tab) => (
          <button key={tab} onClick={() => setActiveTab(tab)} className={`tab-button ${activeTab === tab ? 'tab-active' : ''}`}>
            {tab}
          </button>
        ))}
      </div>
      {filteredRequests.length === 0 ? <EmptyState message={`No ${activeTab !== 'all' ? activeTab : ''} requests found`} /> : (
        <div className="space-y-4">
          {filteredRequests.map((req: any) => {
            const donation = donations.find((d: any) => d.id === req.donationId);
            const donor = donation ? users.find((u: any) => u.id === donation.donorId) : null;
            if (!donation || !donor) return null;
            const canSeeAddress = req.status === 'approved' || req.status === 'completed';
            return (
              <div key={req.id} className="card">
                <div className="grid grid-cols-12 gap-6">
                  <div className="col-span-8">
                    <div className="flex items-start justify-between mb-4">
                      <div><h3 className="card-title mb-1">{donation.title}</h3><div className="card-meta">Donor: <span className="card-value">{donor.displayName}</span></div></div>
                      <StatusBadge status={req.status} />
                    </div>
                    <div className="grid grid-cols-2 gap-4 mb-3">
                      <div className="card-info"><span className="card-label">Location: </span><span className="card-value">{canSeeAddress ? `${donation.address}, ${donation.city}` : donation.city}</span></div>
                      <div className="card-info"><span className="card-label">Pickup Time: </span><span className="card-value">{formatDateTime(req.pickupTime)}</span></div>
                    </div>
                    {req.notes && <div className="card-info mb-3"><span className="card-label">Notes: </span><span className="card-value">{req.notes}</span></div>}
                    {req.discreetPickup && <div className="privacy-badge">🔒 Discreet pickup requested</div>}
                  </div>
                  <div className="col-span-4 flex flex-col gap-2">
                    {req.status === 'completed' ? (
                      <>{!hasReview(req.id) ? <button onClick={() => onLeaveReview(req.id)} className="btn-accent">Leave Review</button> : <div className="status-completed-badge">✓ Review submitted</div>}<button onClick={() => onViewDonation(donation.id)} className="btn-secondary">View Donation</button></>
                    ) : req.status === 'approved' ? (
                      <><button onClick={() => confirm('Mark this pickup as completed?') && onUpdateStatus(req.id, 'completed')} className="btn-primary">Mark Picked Up</button><button onClick={() => confirm('Cancel this request?') && onUpdateStatus(req.id, 'cancelled')} className="btn-danger">Cancel</button></>
                    ) : req.status === 'pending' ? (
                      <><div className="status-pending-badge">⏳ Waiting for approval</div><button onClick={() => confirm('Cancel this request?') && onUpdateStatus(req.id, 'cancelled')} className="btn-cancel">Cancel Request</button></>
                    ) : <button onClick={() => onViewDonation(donation.id)} className="btn-secondary">View Donation</button>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ReviewRating({ request, donation, donor, onBack, onSubmit }: any) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState('');

  return (
    <div>
      <div className="breadcrumb"><button onClick={onBack} className="breadcrumb-link">My Requests</button><span>/</span><span className="breadcrumb-current">Leave Review</span></div>
      <div className="max-w-2xl mx-auto">
        <div className="card">
          <h1 className="review-title mb-6">Leave a Review</h1>
          <div className="review-donation-info">
            <div className="detail-label mb-1">Donation</div>
            <div className="review-donation-title">{donation.title}</div>
            <div className="card-meta mt-2">Donor: <span className="card-value">{donor.displayName}</span></div>
          </div>
          <div className="space-y-6">
            <div>
              <label className="form-label mb-3">Rating <span className="text-red-600">*</span></label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button key={star} onClick={() => setRating(star)} onMouseEnter={() => setHoveredRating(star)} onMouseLeave={() => setHoveredRating(0)} className="star-button" style={{ fontSize: '2.5rem', color: star <= (hoveredRating || rating) ? '#f5a623' : '#d4d4d8' }}>
                    ⭐
                  </button>
                ))}
              </div>
            </div>
            <div><label className="form-label mb-2">Comment</label><textarea rows={6} placeholder="Share your experience with this donation and donor..." value={comment} onChange={(e) => setComment(e.target.value)} className="input-field resize-none" /></div>
            <div className="flex gap-4">
              <button onClick={onBack} className="btn-secondary flex-1">Cancel</button>
              <button onClick={() => { if (rating === 0) { alert('Please select a rating'); return; } onSubmit(rating, comment); }} className="btn-primary flex-1">Submit Review</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Profile({ user, onBack }: any) {
  const [displayName, setDisplayName] = useState(user.displayName);
  const [email, setEmail] = useState(user.email);
  const [phone, setPhone] = useState(user.phone);
  const [dietaryPreferences, setDietaryPreferences] = useState<DietaryTag[]>(user.dietaryPreferences);
  const [discreetPickup, setDiscreetPickup] = useState(user.discreetPickup);

  return (
    <div>
      <div className="mb-8"><h1 className="page-title">Profile Settings</h1><p className="page-subtitle">Manage your account and preferences</p></div>
      <div className="max-w-2xl">
        <div className="card mb-6"><h2 className="section-title mb-4">Personal Information</h2><div className="space-y-4"><div><label className="form-label mb-2">Display Name</label><input type="text" value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="input-field" /></div><div><label className="form-label mb-2">Email</label><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="input-field" /></div><div><label className="form-label mb-2">Phone</label><input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="input-field" /></div></div></div>
        <div className="card mb-6"><h2 className="section-title mb-4">Dietary Preferences</h2><div className="grid grid-cols-2 gap-3">{(['vegan', 'vegetarian', 'gluten_free', 'kosher'] as DietaryTag[]).map((tag) => (<label key={tag} className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={dietaryPreferences.includes(tag)} onChange={() => setDietaryPreferences(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag])} className="w-4 h-4" /><span className="form-checkbox-label">{tag === 'gluten_free' ? 'Gluten-Free' : tag.charAt(0).toUpperCase() + tag.slice(1)}</span></label>))}</div></div>
        <div className="card mb-6"><h2 className="section-title mb-4">Privacy Settings</h2><label className="flex items-start gap-3 cursor-pointer"><input type="checkbox" checked={discreetPickup} onChange={(e) => setDiscreetPickup(e.target.checked)} className="mt-1 w-4 h-4" /><div><div className="privacy-label">Prefer discreet pickups</div><div className="privacy-desc mt-1">When enabled, your pickup requests will default to discreet mode</div></div></label></div>
        <div className="profile-reputation"><h2 className="section-title mb-4">Reputation</h2><div className="flex items-center gap-4"><div className="donor-avatar-large">👤</div><div><div className="donor-name text-lg">{user.displayName}</div><div className="flex items-center gap-1 text-sm">{[...Array(5)].map((_, i) => <span key={i} className={i < Math.floor(user.rating) ? 'star-filled' : 'star-empty'}>⭐</span>)}<span className="rating-value ml-2">{user.rating.toFixed(1)}</span><span className="rating-count">({user.reviewCount} reviews)</span></div></div></div></div>
        <div className="flex gap-4"><button onClick={onBack} className="btn-secondary flex-1">Cancel</button><button onClick={() => { alert('Profile updated (mock action)'); onBack(); }} className="btn-primary flex-1">Save Changes</button></div>
      </div>
    </div>
  );
}